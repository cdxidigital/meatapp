# MEAT 2.0 clean-room development prototype
Open index.html in a browser or deploy this folder as a static site.

## Functional demo
Navigation, filtered synthetic profiles, favourites, swipe-style interest queue, local chat, countdown availability, simulated album permissions and event RSVP.

## Not implemented
Authentication, real users, geolocation, backend, database, realtime messaging, verification, moderation, payments, uploads or secure media delivery. Never use as a production dating platform.

## Proposed production stack
Next.js + TypeScript, PostgreSQL/PostGIS, Redis, WebSocket messaging, object storage with signed URLs, background moderation jobs, OIDC authentication, auditable consent records, abuse reporting and admin console.

## Release gates
18+ age assurance appropriate to jurisdiction, privacy impact assessment, geolocation threat modelling, consent and media rights review, secure file processing, rate limits, content moderation, reporting and appeals, penetration testing, accessibility and load testing.
