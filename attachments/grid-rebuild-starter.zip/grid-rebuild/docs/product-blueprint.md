# GRID Product Blueprint

## 1. Core experience

### Home: Nearby Grid
- Dense card grid of nearby people.
- Default sort: privacy-safe proximity + freshness + relevance.
- Live presence indicator.
- Quick actions: tap/interest, favourite, message, hide.
- Filter drawer with saved filter sets.
- Radius selector: 0.5 / 1 / 5 / 10 / 25 / 50 / 100 km.
- Privacy toggle: hide distance / hide online status / incognito discovery.

### Explore
- MapLibre map for choosing a city/area.
- Never expose another person's exact coordinates.
- Map selection changes the discovery area, not the user's actual location.
- Travel mode for a future location.

### Profiles
- Photo-first profile.
- Identity/display name separated from legal account identity.
- About, tags, interests, looking-for, availability, boundaries.
- Verification badge when independently verified.
- Private media albums with explicit consent and per-person revocation.
- Block/report/safety actions always accessible.

### Chat
- Realtime one-to-one messaging.
- Text, emoji, reactions, photo/video/voice attachments.
- Message requests and consent gates for media.
- Typing/presence status.
- Optional translation.
- Disappearing media with server-enforced expiry.

### Calls
- Voice/video call via LiveKit.
- Explicit call permission and pre-call device check.
- Report/block controls available during/after calls.
- Abuse throttling and call-rate controls.

## 2. Better-than-incumbent differentiators

1. **Privacy Gradient**
   - The user controls what is visible: online, distance, discoverability, map appearance, profile visibility, media permissions.
   - Discovery queries return approximate distance buckets instead of coordinates.

2. **Consent-first media**
   - Albums are private by default.
   - Share request -> accept -> view.
   - Per-recipient revoke.
   - Expiring access enforced server-side.

3. **Smarter discovery**
   - Instead of popularity-only ranking, combine proximity, recent activity, mutual interests, compatibility, response likelihood and user-selected intent.
   - Explain why a profile appeared: e.g. `nearby`, `online`, `shared 4 interests`.

4. **No dark-pattern filters**
   - Filters are understandable, reversible, and shown as active chips.
   - Saved searches are user-created and editable.

5. **Safety centre**
   - Block/report/mute/unmatch.
   - Screenshot-aware privacy messaging where platform APIs allow it.
   - Media moderation before public discovery.
   - Risk scoring and rate limits server-side.
   - Trusted-device sessions and account/session revocation.

6. **Meet-up mode**
   - Optional private countdown/check-in workflow.
   - Share a meeting plan with a trusted contact.
   - Fast exit / safety check-in controls.

7. **Local intelligence**
   - Events, places and local community signals can be overlaid without exposing exact user locations.

## 3. Monetization

Core social functions stay useful for free users.

Optional paid tiers should unlock convenience and power rather than basic human interaction:
- unlimited saved filters
- advanced discovery controls
- travel mode
- profile visibility boosts
- enhanced incognito controls
- expanded private albums
- premium profile customization
- advanced insights

Avoid charging users for safety controls, blocking, reporting, account deletion or basic messaging.
