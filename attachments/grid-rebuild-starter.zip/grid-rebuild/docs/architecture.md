# GRID Technical Architecture

```text
Mobile App (Expo / React Native)
        |
        +-- Auth -------- Supabase Auth
        +-- Data -------- PostgREST / RPC
        +-- Realtime ---- Supabase Realtime
        +-- Media ------- Supabase Storage
        +-- Discovery --- Postgres + PostGIS RPCs
        +-- Calls ------- LiveKit
        +-- Maps -------- MapLibre + vector tiles
        |
        v
 Supabase Postgres
   |-- RLS policies
   |-- privacy-safe location buckets
   |-- discovery functions
   |-- moderation state
   |-- audit events
   +-- notification/event outbox
```

## Security rules

- Treat every client as untrusted.
- No client-controlled user ID inside authorization-sensitive RPCs.
- Derive identity from `auth.uid()`.
- RLS on every user-owned table.
- Discovery RPC exposes only fields required for discovery.
- Never expose raw latitude/longitude for another person.
- Store exact current location only where operationally necessary and with short retention.
- Separate moderation state from public profile state.
- Private media buckets by default.
- Server-side expiry for temporary media access.
- Audit high-risk actions: login, password changes, profile visibility, media sharing, reports, blocks, device/session changes.

## Discovery ranking

A discovery score is intentionally bounded and transparent:

`score = distance_weight + freshness_weight + intent_fit + interest_overlap + activity_signal - safety_penalties`

Do not let popularity or monetization completely dominate discovery.
