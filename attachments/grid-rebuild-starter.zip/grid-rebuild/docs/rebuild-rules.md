# Rebuild Rules

- Reproduce public product capabilities, not proprietary implementation.
- Do not copy Grindr name, logo, screenshots, copy, icons, visual identity or proprietary code.
- Use open-source code only where its license permits the intended use.
- Prefer small, auditable dependencies.
- Every security decision belongs server-side.
- Exact location never leaves the trusted backend boundary.
- Safety controls are always accessible.
- Free users get a coherent product, not a crippled preview.
- Monetization must never override privacy or safety.
