# Build Priority

## Phase 1: usable core
1. Auth and age-gated onboarding.
2. Profile creation and photos.
3. Current-location capture with privacy bucketization.
4. Nearby grid.
5. Filters and saved filters.
6. Profile detail.
7. Block/report.
8. Realtime chat.

## Phase 2: differentiation
1. Explore map.
2. Travel mode.
3. Private albums with consent + expiry.
4. Verification.
5. Voice/video calls.
6. Meet-up safety flow.
7. Explainable discovery.

## Phase 3: scale
1. Moderation pipeline.
2. Notification event bus.
3. Search indexing.
4. Analytics with strict data minimisation.
5. Subscription entitlements.
6. Abuse/rate limiting.
7. Observability and incident tooling.
