import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import * as SQLite from 'expo-sqlite';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY!;

const storage = SQLite.openDatabaseSync('grid-auth.db');
storage.execSync('CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL);');

const dbStorage = {
  getItem: async (key: string) => storage.getFirstSync<{ value: string }>('SELECT value FROM kv WHERE key = ?', key)?.value ?? null,
  setItem: async (key: string, value: string) => storage.runSync('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)', key, value),
  removeItem: async (key: string) => storage.runSync('DELETE FROM kv WHERE key = ?', key),
};

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { storage: dbStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});
