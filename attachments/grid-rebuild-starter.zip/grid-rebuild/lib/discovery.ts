import { supabase } from './supabase';

export type DiscoveryFilters = {
  radiusKm: number;
  minAge?: number;
  maxAge?: number;
  onlineOnly?: boolean;
  tags?: string[];
  lookingFor?: string[];
};

export async function getNearbyProfiles(filters: DiscoveryFilters) {
  const { data, error } = await supabase.rpc('get_nearby_profiles', {
    p_radius_km: filters.radiusKm,
    p_min_age: filters.minAge ?? null,
    p_max_age: filters.maxAge ?? null,
    p_online_only: filters.onlineOnly ?? false,
    p_tags: filters.tags ?? [],
    p_looking_for: filters.lookingFor ?? [],
  });
  if (error) throw error;
  return data;
}
