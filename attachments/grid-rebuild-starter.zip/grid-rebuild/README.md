# GRID Rebuild

A production-oriented, original implementation of a nearby-first LGBTQ+ social discovery app inspired by the *product category* occupied by Grindr. It does **not** copy Grindr proprietary source, assets, trademarks, or visual design.

## Open-source building blocks

- **Weekend**: MIT-licensed open-source dating/social discovery reference implementation using Flutter + Supabase + PostgreSQL/PostGIS + realtime chat + privacy-safe location patterns.
- **Supabase**: open-source backend platform covering Postgres, Auth, Storage, Realtime and Edge Functions.
- **LiveKit**: Apache-2.0 realtime media stack for audio/video/data, with React Native SDKs and self-hosting options.
- **MapLibre React Native**: MIT-licensed native maps for React Native.

## Stack

- Expo SDK 57 / React Native 0.86 / React 19.2.3
- Expo Router
- TypeScript
- Supabase + PostgreSQL + PostGIS + Realtime + Storage
- LiveKit for calls
- MapLibre for Explore map
- Server-side geospatial discovery
- RLS-first authorization

## Bootstrap

```bash
npx create-expo-app@latest grid --template blank-typescript
cd grid
npx expo install expo-router expo-location expo-image expo-image-picker expo-notifications expo-secure-store
npx expo install @supabase/supabase-js react-native-url-polyfill expo-sqlite
npm install @livekit/react-native @livekit/react-native-webrtc livekit-client
npm install @maplibre/maplibre-react-native
```

Then copy the `app`, `components`, `lib`, and `supabase` folders from this repository.

## Environment

```env
EXPO_PUBLIC_SUPABASE_URL=
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=
EXPO_PUBLIC_LIVEKIT_URL=
```

Server-only secrets such as the Supabase service role and LiveKit API secret must never be shipped in the mobile app.

## Product principle

The experience should feel **fast, local, private and human**. Avoid an editorial/social-feed layout. The dominant interaction is a dense, glanceable discovery grid with explicit controls and predictable navigation.
