# Third-party notices

This project is an original implementation and does not include copied Grindr proprietary source, artwork, trademarks or proprietary assets.

## Reference / dependency projects

### Weekend
Repository: https://github.com/zypherlabs-bit/Weekend
License: MIT
Use: reference architecture for nearby discovery, privacy-safe location, Supabase/PostGIS, RLS and safety patterns.

### Supabase
Repository: https://github.com/supabase/supabase
License: Apache-2.0 for the main repository components noted by the project.
Use: backend platform.

### LiveKit React Native SDK
Repository: https://github.com/livekit/client-sdk-react-native
License: Apache-2.0
Use: realtime voice/video/data transport.

### MapLibre React Native
Repository: https://github.com/maplibre/maplibre-react-native
License: MIT
Use: interactive maps.

When copying code from a specific third-party repository into the application, retain the applicable copyright and license notices and review that repository's current license and dependency licenses before redistribution.
