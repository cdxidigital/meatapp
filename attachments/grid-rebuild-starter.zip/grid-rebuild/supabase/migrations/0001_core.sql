create extension if not exists postgis;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 40),
  bio text,
  birth_date date not null,
  city text,
  visibility boolean not null default true,
  show_distance boolean not null default false,
  show_online boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profile_tags (
  profile_id uuid not null references public.profiles(id) on delete cascade,
  tag text not null,
  primary key (profile_id, tag)
);

create table if not exists public.profile_locations (
  profile_id uuid primary key references public.profiles(id) on delete cascade,
  location geography(point, 4326) not null,
  location_bucket text,
  updated_at timestamptz not null default now()
);

create index if not exists profile_locations_gist on public.profile_locations using gist(location);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  conversation_id uuid not null,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text,
  media_path text,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.profile_tags enable row level security;
alter table public.profile_locations enable row level security;
alter table public.blocks enable row level security;
alter table public.messages enable row level security;

create policy profiles_self_read on public.profiles for select to authenticated using (id = auth.uid() or visibility = true);
create policy profiles_self_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy tags_public_read on public.profile_tags for select to authenticated using (true);
create policy location_self_write on public.profile_locations for insert to authenticated with check (profile_id = auth.uid());
create policy location_self_update on public.profile_locations for update to authenticated using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy blocks_owner on public.blocks for all to authenticated using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

create or replace function public.get_nearby_profiles(
  p_radius_km double precision default 25,
  p_min_age integer default null,
  p_max_age integer default null,
  p_online_only boolean default false,
  p_tags text[] default '{}',
  p_looking_for text[] default '{}'
)
returns table (
  id uuid,
  display_name text,
  city text,
  approximate_distance_km integer,
  is_online boolean
)
language sql
security definer
set search_path = public
as $$
  with me as (
    select location from public.profile_locations where profile_id = auth.uid()
  )
  select
    p.id,
    p.display_name,
    p.city,
    greatest(1, round(st_distance(pl.location, me.location) / 1000.0)::integer) as approximate_distance_km,
    (p.updated_at > now() - interval '10 minutes') as is_online
  from public.profiles p
  join public.profile_locations pl on pl.profile_id = p.id
  cross join me
  where p.id <> auth.uid()
    and p.visibility = true
    and st_dwithin(pl.location, me.location, p_radius_km * 1000.0)
    and not exists (
      select 1 from public.blocks b
      where (b.blocker_id = auth.uid() and b.blocked_id = p.id)
         or (b.blocker_id = p.id and b.blocked_id = auth.uid())
    )
  order by st_distance(pl.location, me.location), p.updated_at desc
  limit 100;
$$;
