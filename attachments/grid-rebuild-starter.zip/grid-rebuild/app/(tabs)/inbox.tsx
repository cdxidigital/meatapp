import { StyleSheet, Text, View } from 'react-native';
export default function Inbox(){return <View style={styles.container}><Text style={styles.title}>Messages</Text><Text style={styles.body}>Realtime conversations, media permissions, reactions and calls.</Text></View>}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#09090b',padding:24,paddingTop:72},title:{color:'#fff',fontSize:30,fontWeight:'800'},body:{color:'#a1a1aa',lineHeight:23,marginTop:12}})
