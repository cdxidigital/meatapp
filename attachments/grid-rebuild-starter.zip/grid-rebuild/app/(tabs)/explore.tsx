import { StyleSheet, Text, View } from 'react-native';
export default function Explore(){return <View style={styles.container}><Text style={styles.title}>Explore</Text><Text style={styles.body}>MapLibre goes here. Select an area to browse profiles without revealing anyone's exact location.</Text></View>}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#09090b',padding:24,paddingTop:72},title:{color:'#fff',fontSize:30,fontWeight:'800'},body:{color:'#a1a1aa',lineHeight:23,marginTop:12}})
