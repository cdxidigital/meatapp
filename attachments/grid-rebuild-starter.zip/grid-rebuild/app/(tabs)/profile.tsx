import { StyleSheet, Text, View } from 'react-native';
export default function Profile(){return <View style={styles.container}><Text style={styles.title}>Your profile</Text><Text style={styles.body}>Identity, discovery visibility, media sharing and safety controls.</Text></View>}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#09090b',padding:24,paddingTop:72},title:{color:'#fff',fontSize:30,fontWeight:'800'},body:{color:'#a1a1aa',lineHeight:23,marginTop:12}})
