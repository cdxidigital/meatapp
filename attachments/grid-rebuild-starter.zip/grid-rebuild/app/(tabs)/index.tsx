import { FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';

const demo = Array.from({ length: 12 }, (_, i) => ({
  id: String(i + 1), name: ['Alex','Jordan','Sam','Chris'][i % 4], distance: `${i + 1} km`, online: i % 3 !== 0,
  photo: `https://picsum.photos/seed/grid-${i + 1}/600/800`,
}));

export default function Nearby() {
  const router = useRouter();
  return <View style={styles.container}>
    <View style={styles.header}><View><Text style={styles.brand}>GRID</Text><Text style={styles.subtitle}>Nearby now</Text></View><Pressable style={styles.filter}><Text style={styles.filterText}>Filter</Text></Pressable></View>
    <FlatList data={demo} numColumns={2} keyExtractor={(x)=>x.id} columnWrapperStyle={styles.row} contentContainerStyle={styles.grid}
      renderItem={({item}) => <Pressable style={styles.card} onPress={() => router.push(`/profile/${item.id}`)}>
        <Image source={{uri:item.photo}} style={styles.photo}/><View style={styles.meta}><View style={styles.nameLine}><Text style={styles.name}>{item.name}</Text>{item.online ? <View style={styles.dot}/> : null}</View><Text style={styles.distance}>{item.distance}</Text></View>
      </Pressable>}/>
  </View>
}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#09090b'},header:{paddingTop:58,paddingHorizontal:18,paddingBottom:12,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},brand:{color:'#fff',fontSize:22,fontWeight:'800',letterSpacing:1.5},subtitle:{color:'#8f8f98',marginTop:2},filter:{paddingHorizontal:14,paddingVertical:9,borderRadius:18,backgroundColor:'#17171b'},filterText:{color:'#fff',fontWeight:'700'},grid:{paddingHorizontal:10,paddingBottom:28},row:{gap:10},card:{flex:1,marginBottom:10,borderRadius:16,overflow:'hidden',backgroundColor:'#141418'},photo:{width:'100%',aspectRatio:.78},meta:{padding:10},nameLine:{flexDirection:'row',alignItems:'center',gap:7},name:{color:'#fff',fontSize:16,fontWeight:'700'},distance:{color:'#8f8f98',marginTop:3,fontSize:12},dot:{width:7,height:7,borderRadius:4,backgroundColor:'#34d399'}})
