import { StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
export default function ChatScreen(){const {id}=useLocalSearchParams<{id:string}>();return <View style={styles.container}><Text style={styles.title}>Chat</Text><Text style={styles.meta}>Conversation with {id}</Text><Text style={styles.body}>Connect Supabase Realtime here. Media permissions and expiry must be enforced server-side.</Text></View>}
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#09090b',padding:24,paddingTop:72},title:{color:'#fff',fontSize:30,fontWeight:'800'},meta:{color:'#a1a1aa',marginTop:6},body:{color:'#71717a',lineHeight:22,marginTop:18}})
