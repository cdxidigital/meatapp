#!/usr/bin/env python3
"""Rebuild the MEAT guide from this kit's real vector, raster, and font assets.

Python 3.10+; reportlab, svglib, Pillow. Run from any working directory.
No network requests, remote fonts, or external artwork are used by this builder.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import html
import json
import math
from pathlib import Path

from PIL import Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.pdfgen import canvas
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg

KIT = Path(__file__).resolve().parents[1]
W, H = 1280, 720
VERSION = '2.0'
DATE = '17 October 2026'
COLOURS = {
    'charcoal': '#0E1014', 'coral': '#FF6389', 'lime': '#B7DFA5',
    'paper': '#F5F3F0', 'panel': '#17191F', 'muted': '#9C9DA9',
}
FIELD_LABELS = [
    "Why I'm here", "What I'm looking for", "Who I'd like to meet", 'My sexual role',
    "Roles I'm interested in", 'My kink dynamic', "What I'm into", 'My experience',
    'How to approach me', 'My boundaries', 'Relationship situation', 'Relationship style',
    'How I like to meet', 'Hosting and travel', 'Right now',
]
INTEREST_GROUPS = {
    'Touch & intimacy': ['Kissing', 'Cuddling', 'Sensual massage', 'Mutual touch', 'Taking it slow'],
    'Sex & play': ['Oral sex', 'Anal sex', 'Vaginal / front-hole sex', 'Mutual masturbation',
                   'Non-penetrative sex', 'Sex toys', 'Strap-on play', 'Dirty talk'],
    'Kink & style': ['BDSM', 'Bondage', 'Adult roleplay', 'Sensation play', 'Spanking',
                     'Power exchange', 'Praise', 'Leather', 'Latex', 'Harnesses', 'Lingerie', 'Foot play'],
    'Shared experiences': ['Threesomes', 'Group play', 'Watching, by agreement', 'Being watched, by agreement'],
    'Digital intimacy': ['Sexting', 'Private photo sharing', 'Consensual video intimacy'],
}
PALETTE_ROLES = {
    'charcoal': ('Charcoal', 'The primary ground. Calm, deep and direct.'),
    'coral': ('Coral', 'The signature accent. Use for identity and the next action.'),
    'lime': ('Lime', 'A secondary accent. Pair with words, never a promise.'),
    'paper': ('Paper', 'Primary text on dark; open space on light.'),
    'panel': ('Panel', 'A quiet surface for cards and grouped controls.'),
    'muted': ('Muted', 'Secondary copy on dark. Keep essential text strong.'),
}
PAIRINGS = [
    ('paper', 'charcoal', 'Primary text'), ('coral', 'charcoal', 'Identity and links'),
    ('charcoal', 'coral', 'Primary action'), ('charcoal', 'lime', 'Secondary highlight'),
    ('coral', 'paper', 'Avoid for normal text'), ('paper', 'coral', 'Avoid for normal text'),
]
LOGOS = {
    'primary': 'logos/svg/meat-primary.svg', 'reversed': 'logos/svg/meat-reversed.svg',
    'black': 'logos/svg/meat-black.svg', 'white': 'logos/svg/meat-white.svg',
    'mark_coral': 'logos/svg/meat-mark-coral.svg', 'mark_charcoal': 'logos/svg/meat-mark-charcoal.svg',
    'mark_white': 'logos/svg/meat-mark-white.svg',
    'wordmark_coral': 'logos/svg/meat-wordmark-coral.svg',
    'mark_slash': 'logos/svg/meat-mark-slash-reversed.svg',
}
SOCIAL = {
    'open_graph': 'social/meat-open-graph-1200x630.png',
    'banner': 'social/meat-banner-1500x500.png',
    'square': 'social/meat-square-1080x1080.png',
}
TITLES = [
    'Cover', 'Introduction', 'The wordmark', 'Logo versions', 'Clear space and size',
    'Misuse', 'Palette', 'Colour pairings', 'Typography', 'Icons', 'Applications',
    'Voice and tone', 'The asset kit',
]


def colour(value):
    return colors.HexColor(COLOURS.get(value, value))


def rgb(value):
    value = COLOURS.get(value, value).lstrip('#')
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))


def contrast(a, b):
    def luminance(value):
        channels = [part / 255 for part in rgb(value)]
        channels = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in channels]
        return sum(v * k for v, k in zip(channels, (.2126, .7152, .0722)))
    high, low = sorted([luminance(a), luminance(b)], reverse=True)
    return (high + .05) / (low + .05)


def require(path):
    p = KIT / path
    if not p.is_file() or p.stat().st_size == 0:
        raise FileNotFoundError(f'Required kit asset is missing: {path}')
    return p


def resolve_font(stem):
    exact = KIT / 'fonts' / f'{stem}.ttf'
    if exact.is_file():
        return exact
    matches = sorted((KIT / 'fonts').rglob(f'{stem}.ttf'))
    if len(matches) != 1:
        raise FileNotFoundError(f'Expected one real bundled font: {stem}.ttf')
    return matches[0]


class Guide:
    def __init__(self, output):
        for name, stem in [('Display', 'Montserrat-Black'), ('Body', 'Inter-Regular'),
                           ('Medium', 'Inter-Medium'), ('Bold', 'Inter-Bold')]:
            pdfmetrics.registerFont(TTFont(name, str(resolve_font(stem))))
        pdfmetrics.registerFontFamily('Body', normal='Body', bold='Bold', italic='Body', boldItalic='Bold')
        self.c = canvas.Canvas(str(output), pagesize=(W, H), pageCompression=1)
        self.c.setTitle('MEAT Brand Guide - Proposed Refinement - Version 2.0')
        self.c.setAuthor('MEAT')
        self.c.setSubject('Brand identity, production assets, colour, typography and product voice')
        self.page = 0
        self.boxes = []
        self.svg_cache = {}

    def record(self, kind, x, top, width, height, label):
        self.boxes.append(dict(page=self.page, kind=kind, x=round(x, 3), top=round(top, 3),
                               width=round(width, 3), height=round(height, 3), label=label))

    def rect(self, x, top, width, height, fill='panel', stroke=None, radius=0, line_width=1):
        self.c.setLineWidth(line_width)
        if fill:
            self.c.setFillColor(colour(fill))
        if stroke:
            self.c.setStrokeColor(colour(stroke))
        method = self.c.roundRect if radius else self.c.rect
        args = (x, H-top-height, width, height, radius) if radius else (x, H-top-height, width, height)
        method(*args, fill=bool(fill), stroke=bool(stroke))

    def line(self, x1, top1, x2, top2, value='muted', width=1, dash=None):
        self.c.saveState()
        self.c.setStrokeColor(colour(value))
        self.c.setLineWidth(width)
        if dash:
            self.c.setDash(dash)
        self.c.line(x1, H-top1, x2, H-top2)
        self.c.restoreState()

    def text(self, value, x, top, size=18, fill='paper', font='Body', tracking=None):
        self.c.saveState()
        self.c.setFillColor(colour(fill))
        obj = self.c.beginText(x, H-top-size)
        obj.setFont(font, size)
        obj.setCharSpace(tracking or 0)
        obj.textLine(value)
        self.c.drawText(obj)
        self.c.restoreState()
        width = pdfmetrics.stringWidth(value, font, size) + ((len(value)-1)*tracking if tracking else 0)
        self.record('text', x, top, width, size*1.15, value)
        return width

    def para(self, value, x, top, width, size=18, leading=None, fill='paper', font='Body'):
        style = ParagraphStyle('paragraph', fontName=font, fontSize=size, leading=leading or size*1.45,
                               textColor=colour(fill), spaceAfter=0, splitLongWords=False)
        paragraph = Paragraph(html.escape(value).replace('\n', '<br/>'), style)
        _, height = paragraph.wrap(width, 1000)
        self.c.saveState()
        text_state = self.c.beginText()
        text_state.setCharSpace(0)
        self.c.drawText(text_state)
        paragraph.drawOn(self.c, x, H-top-height)
        self.c.restoreState()
        self.record('paragraph', x, top, width, height, value)
        return height

    def label(self, value, x, top, fill='muted', size=12):
        self.text(value.upper(), x, top, size=size, fill=fill, font='Bold', tracking=1.25)

    def svg(self, rel, x, top, width, *, height_scale=1, rotate=0, recolour=None):
        if rel not in self.svg_cache:
            self.svg_cache[rel] = svg2rlg(str(require(rel)))
        drawing = copy.deepcopy(self.svg_cache[rel])
        if drawing is None:
            raise ValueError(f'SVG could not be parsed: {rel}')
        if recolour:
            def visit(item):
                if hasattr(item, 'fillColor') and item.fillColor is not None:
                    item.fillColor = colour(recolour)
                for child in getattr(item, 'contents', []):
                    visit(child)
            visit(drawing)
        x0, y0, x1, y1 = drawing.getBounds()
        scale = width/(x1-x0)
        height = (y1-y0)*scale*height_scale
        self.c.saveState()
        if rotate:
            self.c.translate(x+width/2, H-top-height/2)
            self.c.rotate(rotate)
            self.c.translate(-width/2, -height/2)
        else:
            self.c.translate(x, H-top-height)
        self.c.scale(scale, scale*height_scale)
        self.c.translate(-x0, -y0)
        renderPDF.draw(drawing, self.c, 0, 0)
        self.c.restoreState()
        self.record('svg', x, top, width, height, rel)
        return height

    def image(self, rel, x, top, width, height=None):
        path = require(rel)
        with Image.open(path) as img:
            iw, ih = img.size
        height = height or width*ih/iw
        self.c.drawImage(str(path), x, H-top-height, width, height, mask='auto')
        self.record('image', x, top, width, height, rel)
        return height

    def svg_fit(self, rel, x, top, width, height):
        drawing = svg2rlg(str(require(rel)))
        x0, y0, x1, y1 = drawing.getBounds()
        factor = min(width/(x1-x0), height/(y1-y0))
        actual_width, actual_height = (x1-x0)*factor, (y1-y0)*factor
        return self.svg(rel, x+(width-actual_width)/2, top+(height-actual_height)/2, actual_width)

    def start(self, name, title, subtitle='', dark=True):
        self.page += 1
        self.dark = dark
        self.rect(0, 0, W, H, 'charcoal' if dark else 'paper')
        self.label(f'MEAT / {name}', 64, 34, 'muted' if dark else '#62636B')
        self.text(f'{self.page:02d}', 1173, 29, 21, 'coral' if dark else 'charcoal', 'Display')
        if title:
            self.text(title, 64, 75, 42, 'paper' if dark else 'charcoal', 'Display')
        if subtitle:
            self.para(subtitle, 66, 135, 1120, 16, 23, 'muted' if dark else '#55565E')

    def footer(self, note='PROPOSED REFINEMENT / V2.0'):
        self.line(64, 671, 1216, 671, '#32343D' if self.dark else '#CECCC9')
        self.text('MEAT', 64, 684, 12, 'paper' if self.dark else 'charcoal', 'Bold')
        self.text(note, 124, 684, 11, 'muted' if self.dark else '#62636B', 'Medium')
        self.text(f'BRAND GUIDE / {self.page:02d}', 1092, 684, 11, 'muted' if self.dark else '#62636B', 'Medium')
        self.c.showPage()

    def build(self):
        self.cover(); self.introduction(); self.wordmark(); self.variants(); self.space_size()
        self.misuse(); self.palette(); self.pairings(); self.typography(); self.icons()
        self.applications(); self.voice(); self.asset_kit()
        assert self.page == 13
        self.c.save()

    def cover(self):
        self.start('Brand guide', '', dark=True)
        self.svg(LOGOS['reversed'], 140, 174, 1000)
        self.text('Connection.', 64, 492, 56, 'paper', 'Display')
        self.text('On your terms.', 64, 551, 56, 'coral', 'Display')
        self.para('An app-aligned refinement of the earlier MEAT identity proposal.\nExact name. Clear choices. Room for possibility.', 866, 506, 327, 19, 28, 'muted')
        self.footer()

    def introduction(self):
        self.start('Introduction', 'Clear intentions. More possibility.',
                   'A confident adult connection brand, with enough space for people to define themselves.', dark=False)
        self.para('MEAT\'s current preview centres on men seeking men in Perth. Desire, dating, friendship and community belong in the same conversation. The brand is direct, warm and comfortable with adult language.',
                  64, 199, 482, 21, 30, 'charcoal')
        self.rect(64, 401, 482, 202, 'charcoal', radius=18)
        self.label('THE EVIDENCE BOUNDARY', 88, 424, 'coral')
        self.para('The earlier 1.0 guide is recovered. Its Montserrat and Inter direction is retained. This edition proposes the app palette, slash detail and rebuilt production geometry. Prior approval and original vector masters were not established.',
                  88, 455, 434, 16, 24, 'paper')
        self.text('15', 604, 194, 52, 'charcoal', 'Display')
        self.text('optional profile groups', 682, 214, 19, 'charcoal', 'Bold')
        self.text('32', 941, 194, 52, 'charcoal', 'Display')
        self.text('interests', 1025, 214, 19, 'charcoal', 'Bold')
        for index, label in enumerate(FIELD_LABELS):
            col, row = divmod(index, 8)
            x = 604 + col*306
            top = 290 + row*35
            self.text(f'{index+1:02d}', x, top+1, 12, '#66676E', 'Medium')
            self.text(label, x+32, top, 15, 'charcoal', 'Medium')
        self.para('All optional. Four interest stances. No selection implies consent.', 604, 593, 585, 16, 23, '#55565E')
        self.footer()

    def wordmark(self):
        self.start('The wordmark', 'One name. One complete signature.',
                   'Use MEAT in uppercase. Use MEAT app when a descriptor helps; keep app lowercase.', dark=False)
        self.rect(64, 191, 1152, 278, '#E9E7E4', radius=18)
        self.svg_fit(LOGOS['primary'], 126, 260, 1020, 134)
        self.para('Lettering', 64, 486, 334, 22, 29, 'charcoal', 'Bold')
        self.para('Montserrat Black is recovered from the prior guide. The supplied outline geometry is a new production reconstruction, not an extracted original master.',
                  64, 526, 334, 17, 25, '#55565E')
        self.para('Slanted accent', 461, 486, 334, 22, 29, 'charcoal', 'Bold')
        self.para('The coral bar carries forward the current app direction. It is a proposed addition to the earlier wordmark. Keep it joined to the supplied lockup.',
                  461, 526, 334, 17, 25, '#55565E')
        self.para('Naming', 858, 486, 334, 22, 29, 'charcoal', 'Bold')
        self.para('Do not expand MEAT into an acronym. NEXT may label a preview edition outside the logo; it is not part of the brand name or production master.',
                  858, 526, 334, 17, 25, '#55565E')
        self.footer('RECONSTRUCTED LETTERING / PROPOSED SLASH DETAIL')

    def variants(self):
        self.start('Logo versions', 'Use the right master for the surface.',
                   'All four versions share the same production geometry. Choose the file; do not recolour by eye.')
        cards = [
            (64, 197, 'paper', 'primary', 'Primary / light surfaces', 'Charcoal lettering + coral accent'),
            (658, 197, 'panel', 'reversed', 'Reversed / dark surfaces', 'Paper lettering + coral accent'),
            (64, 419, '#FFFFFF', 'black', 'Solid black / one colour', 'For single-ink or simple reproduction'),
            (658, 419, '#24262D', 'white', 'Solid white / one colour', 'For dark single-colour applications'),
        ]
        for x, top, bg, logo, heading, caption in cards:
            self.rect(x, top, 558, 181, bg, radius=15)
            self.svg_fit(LOGOS[logo], x+49, top+33, 460, 62)
            self.text(heading, x+21, top+128, 16, 'charcoal' if logo in ['primary','black'] else 'paper', 'Bold')
            self.text(caption, x+21, top+153, 13, '#62636B' if logo in ['primary','black'] else 'muted')
        self.svg(LOGOS['wordmark_coral'],64,621,130)
        self.para('Continuity companion: plain MEAT in Coral. The two-colour slash signatures are a proposed app-aligned refinement of the earlier coral wordmark.',
                  246,620,941,15,21,'muted')
        self.footer()

    def space_size(self):
        self.start('Clear space and size', 'Give the name room to be recognised.',
                   'Proposed rules for these reconstructed masters. Measurements refer to visible artwork, not transparent file padding.', dark=False)
        self.rect(64, 192, 665, 311, '#E9E7E4', radius=18)
        self.label('CLEAR SPACE / HALF THE CAPITAL HEIGHT', 89, 216, '#62636B')
        width = 440
        drawing = svg2rlg(str(require(LOGOS['primary'])))
        x0,y0,x1,y1 = drawing.getBounds()
        height = (y1-y0)*width/(x1-x0)
        x, top = 177, 310
        gap = height/2
        self.rect(x-gap, top-gap, width+2*gap, height+2*gap, None, '#9899A0', radius=0)
        self.svg(LOGOS['primary'], x, top, width)
        self.line(x, top-12, x+width, top-12, 'coral', dash=[3,3])
        self.line(x, top+height+12, x+width, top+height+12, 'coral', dash=[3,3])
        self.text('x', x-gap+10, top-gap+10, 18, 'charcoal', 'Bold')
        self.text('x = 0.5 × capital M height', 89, 455, 20, 'charcoal', 'Bold')
        self.para('Keep equal clear space on every side of the complete signature, including the slanted bar. Keep copy, edges, photographs and other marks outside this area.',
                  64, 530, 665, 18, 26, '#55565E')
        self.label('VISIBLE-WIDTH SCREEN REFERENCES', 785, 206, '#62636B')
        self.svg(LOGOS['primary'], 786, 254, 112)
        self.text('112 px', 926, 248, 28, 'charcoal', 'Bold')
        self.para('Minimum full signature', 926, 291, 265, 16, 22, '#55565E')
        self.rect(776,337,128,47,'charcoal',radius=5)
        self.svg(LOGOS['wordmark_coral'], 796, 350, 88)
        self.text('88 px', 926, 337, 28, 'charcoal', 'Bold')
        self.para('Plain wordmark companion', 926, 375, 265, 16, 22, '#55565E')
        self.svg(LOGOS['mark_charcoal'], 786, 440, 24)
        self.text('24 px', 926, 426, 28, 'charcoal', 'Bold')
        self.para('Compact M; favicon 16 px', 926, 464, 265, 16, 22, '#55565E')
        self.rect(780,514,76,49,'charcoal',radius=5)
        self.svg(LOGOS['mark_slash'], 797, 526, 32)
        self.text('32 px', 926, 514, 28, 'charcoal', 'Bold')
        self.para('Optional M / slash', 926, 552, 265, 16, 22, '#55565E')
        self.para('One guide point equals one reference pixel in a 72 dpi render. Check the actual interface at native size. No production print minimum is established; proof it with the supplier.',
                  785, 597, 416, 13, 19, '#55565E')
        self.footer('PROPOSED MINIMA / 112 PX SIGNATURE / 88 PX PLAIN WORDMARK')

    def misuse(self):
        self.start('Misuse', 'Keep the character. Keep the clarity.',
                   'These intentionally incorrect examples use the same supplied vector geometry.', dark=False)
        cells = [
            ('Do not stretch or squash.', 'stretch'), ('Do not rotate the signature.', 'rotate'),
            ('Do not improvise colours.', 'colour'), ('Do not lose contrast.', 'contrast'),
            ('Do not crowd the mark.', 'crowd'), ('Do not attach an edition name.', 'edition'),
        ]
        for i, (caption, effect) in enumerate(cells):
            x, top = 64+(i%3)*394, 195+(i//3)*224
            self.rect(x, top, 364, 192, '#E9E7E4', radius=14)
            options = dict(height_scale=.55) if effect=='stretch' else dict(rotate=11) if effect=='rotate' else dict(recolour='#3A69C7') if effect=='colour' else dict(recolour='#CECCC9') if effect=='contrast' else {}
            self.svg(LOGOS['primary'], x+41, top+55, 280, **options)
            if effect=='crowd':
                self.rect(x+30, top+49, 302, 75, None, 'charcoal', line_width=2)
                self.text('Too close.', x+117, top+28, 15, 'charcoal', 'Bold')
            if effect=='edition':
                self.text('NEXT', x+223, top+112, 20, 'charcoal', 'Bold')
            self.line(x+22, top+158, x+31, top+167, '#AD274D', 2)
            self.line(x+31, top+158, x+22, top+167, '#AD274D', 2)
            self.text(caption, x+43, top+150, 15, 'charcoal', 'Medium')
        self.footer('INCORRECT EXAMPLES / DO NOT USE THESE TREATMENTS')

    def palette(self):
        self.start('Palette', 'A deep ground. A confident accent.',
                   'This proposed v2 palette matches the rebuilt app direction. The earlier palette remains in the preserved reference.', dark=False)
        for i, key in enumerate(['charcoal','coral','lime']):
            x=64+i*394
            self.rect(x, 191, 364, 305, key, radius=14)
            fg='paper' if key=='charcoal' else 'charcoal'
            name,role=PALETTE_ROLES[key]
            self.text(name, x+24, 215, 29, fg, 'Display')
            self.text(COLOURS[key], x+24, 279, 31, fg, 'Bold')
            self.text('RGB '+ ' / '.join(str(v) for v in rgb(key)), x+24, 325, 16, fg, 'Medium')
            self.para(role, x+24, 405, 316, 17, 25, fg)
        for i,key in enumerate(['paper','panel','muted']):
            x=64+i*394
            self.rect(x, 524, 76, 80, key, '#B8B8BC' if key=='paper' else None, radius=8)
            self.text(PALETTE_ROLES[key][0], x+96, 524, 21, 'charcoal', 'Bold')
            self.text(COLOURS[key], x+96, 556, 18, 'charcoal', 'Medium')
            self.text('RGB '+' / '.join(str(v) for v in rgb(key)), x+96, 584, 13, '#55565E')
        self.para('Use digital sRGB values as the source of truth. No Pantone match or print conversion is specified. Never make colour the sole carrier of a choice, warning or status.',
                  64, 619, 1140, 15, 22, '#55565E')
        self.footer()

    def pairings(self):
        self.start('Colour pairings', 'Contrast is part of the design.',
                   'Choose combinations from exact solid tokens. Ratios below are calculated, not sampled from artwork.')
        for i,(fg,bg,role) in enumerate(PAIRINGS):
            x,top=64+(i%3)*394,197+(i//3)*192
            ratio=contrast(fg,bg)
            self.rect(x, top, 364, 159, bg, '#3B3D46', radius=12)
            self.text('Clear intentions.', x+22, top+24, 26, fg, 'Bold')
            self.text(f'{ratio:.2f}:1', x+22, top+73, 26, fg, 'Bold')
            self.text(role, x+22, top+118, 15, fg, 'Medium')
            self.label('NORMAL TEXT PASS' if ratio>=4.5 else 'NORMAL TEXT FAIL', x+186, top+82, fg, 10)
        self.para('Normal text needs at least 4.5:1 under WCAG 2.2 AA; qualifying large text needs 3:1. This check covers these solid pairs only. Photographs, opacity, gradients and real interface states need their own assessment.',
                  64, 591, 1128, 16, 24, 'muted')
        self.text('Reference: W3C WCAG 2.2 / Understanding 1.4.3 Contrast (Minimum)', 64, 646, 12, 'muted', 'Medium')
        self.footer('SOLID sRGB PAIRS / NOT AN INTERFACE ACCESSIBILITY CERTIFICATION')

    def typography(self):
        self.start('Typography', 'Strong name. Human conversation.',
                   'Retain the earlier guide\'s Montserrat and Inter direction, using the real licensed font files in this kit.', dark=False)
        self.label('DISPLAY / MONTSERRAT BLACK', 64, 199, '#62636B')
        self.text('MAKE IT', 64, 235, 67, 'charcoal', 'Display')
        self.text('YOUR CALL.', 64, 307, 67, 'charcoal', 'Display')
        self.text('Aa Bb Cc / 0123456789', 64, 409, 28, 'charcoal', 'Display')
        self.para('Use Black for the wordmark and short display statements. Keep longer reading and controls in Inter. Preserve actual weights; do not simulate bold.',
                  64, 488, 486, 18, 27, '#55565E')
        self.para('The prior guide establishes the proposed families, not a recovered original font binary. This kit includes sourced fonts and their licences. See fonts/ for provenance.',
                  64, 599, 486, 14, 21, '#55565E')
        rows=[('HEADING','Your next connection.','Bold',31,'Inter Bold / 700 / suggested 32:38'),
              ('BODY','Say what you want. Share what feels right.','Body',19,'Inter Regular / 400 / suggested 17:26'),
              ('CONTROL','Save preferences','Bold',19,'Inter Bold / 700 / suggested 15:20'),
              ('CAPTION','Saved on this device.','Medium',15,'Inter Medium / 500 / suggested 12:18')]
        for i,(label,sample,font,size,detail) in enumerate(rows):
            top=203+i*109
            self.label(label, 654, top, '#62636B')
            self.text(sample, 654, top+26, size, 'charcoal', font)
            self.text(detail, 654, top+69, 13, '#62636B', 'Medium')
            if i<3:self.line(654, top+93, 1203, top+93, '#CFCDCA')
        self.footer('RECOVERED TYPE DIRECTION / SOURCED LICENSED FONT FILES')

    def icons(self):
        self.start('Icons', 'A small space. A familiar shape.',
                   'The plain M retains the earlier compact direction. The optional M / slash is a proposed companion.', dark=False)
        self.image('icons/icon-512.png', 64, 201, 180, 180)
        self.text('App tile', 64, 400, 20, 'charcoal', 'Bold')
        self.para('Opaque ground. Keep the built-in padding.', 64, 431, 230, 17, 24, '#55565E')
        self.rect(344, 201, 180, 180, '#E9E7E4', radius=18)
        self.svg(LOGOS['mark_charcoal'], 385, 249, 98)
        self.text('Compact glyph', 344, 400, 20, 'charcoal', 'Bold')
        self.para('Transparent art. Use when the full name will not fit.', 344, 431, 235, 17, 24, '#55565E')
        self.image('icons/maskable-512.png', 668, 201, 212, 212)
        self.c.saveState(); self.c.setStrokeColor(colour('paper')); self.c.setLineWidth(1); self.c.setDash([5,4])
        self.c.circle(774,H-307,212*.4,fill=0,stroke=1);self.c.restoreState()
        self.text('Maskable tile', 912, 208, 22, 'charcoal', 'Bold')
        self.para('The background fills the canvas. Important foreground stays inside the centred 40% radius circle. The circle is a guide, not part of the export.',
                  912, 252, 280, 17, 25, '#55565E')
        self.label('NATIVE-SIZE SCREEN REFERENCES', 64, 520, '#62636B')
        for size,x in [(64,64),(48,197),(32,314),(24,415),(16,508)]:
            rel = f'icons/favicon-{size}.png' if size in (16,32,48) else 'icons/icon-192.png'
            self.image(rel, x, 558, size, size)
            self.text(str(size), x, 630, 13, 'charcoal', 'Medium')
        self.para('24 px is the proposed general compact minimum. 16 px is reserved for the inspected favicon use. Add a MEAT text label in unfamiliar contexts.',
                  668, 527, 524, 17, 26, '#55565E')
        self.footer('PROPOSED COMPACT COMPANION / ACTUAL EXPORTS SHOWN')

    def applications(self):
        self.start('Applications', 'One identity. Different ways in.',
                   'These are the finished files supplied in social/. Adapt copy and cropping for the final placement.')
        self.image(SOCIAL['open_graph'], 64, 191, 492)
        self.text('OPEN GRAPH / 1200 × 630', 64, 461, 12, 'muted', 'Bold')
        self.image(SOCIAL['banner'], 64, 493, 450)
        self.text('BANNER / 1500 × 500', 64, 649, 12, 'muted', 'Bold')
        self.image(SOCIAL['square'], 715, 191, 430, 430)
        self.text('SQUARE / 1080 × 1080', 715, 641, 12, 'muted', 'Bold')
        self.footer('FINISHED SOCIAL ASSETS / NOT SCREENSHOTS OF A LIVE SERVICE')

    def voice(self):
        self.start('Voice and tone', 'Direct about desire. Clear about choice.',
                   'Adult language can be simple, precise and warm. A profile preference opens a conversation.')
        self.text('A clear yes.', 64, 199, 58, 'paper', 'Display')
        self.text('A kind no.', 64, 267, 58, 'coral', 'Display')
        self.text('Room to', 64, 335, 58, 'paper', 'Display')
        self.text('decide.', 64, 403, 58, 'paper', 'Display')
        principles=[
            ('SAY IT PLAINLY', '"Casual sex" and "Go on dates" are both valid choices.'),
            ('LEAVE ROOM', '"Choose what feels like you. You can leave this blank."'),
            ('NAME THE BOUNDARY', '"Ask before explicit photos." Preferences never equal consent.'),
            ('TELL THE PRODUCT TRUTH', '"Saved on this device." "Sample message - not sent."'),
        ]
        for i,(label,sample) in enumerate(principles):
            top=202+i*98
            self.label(label, 659, top, 'coral')
            self.para(sample, 659, top+27, 525, 19, 28, 'paper')
        self.para('Avoid pressure, fetishising labels and invented privacy or safety promises. An adult self-declaration is not verified age. Local sample conversations are not live chat.',
                  64, 525, 488, 17, 25, 'muted')
        widths=[105,102,132,130]
        start=659
        for label,width in zip(['Into it','Curious','Discuss first','Not for me'],widths):
            self.rect(start, 604, width, 39, 'panel', '#484A55', radius=19)
            self.text(label,start+16,615,14,'paper','Medium')
            start+=width+10
        self.footer('FOUR STANCES / EVERY FIELD OPTIONAL / CONSENT IS SPECIFIC')

    def asset_kit(self):
        self.start('The asset kit', 'Use the files. Keep the system together.',
                   'The guide documents the actual supplied assets. Preserve the prior reference and proposal status.', dark=False)
        entries=[
            ('logos/svg + logos/png','Outlined primary, reversed, black and white signatures; compact companions. Transparent PNG exports at 512, 1024 and 2048 px canvas widths.'),
            ('icons','Favicon SVG and ICO, Apple touch icon, install icons and a maskable tile with a separate foreground for geometry checks.'),
            ('social','Finished 1200 × 630, 1500 × 500 and 1080 × 1080 artwork. Reusable formats; review each destination\'s crop.'),
            ('fonts + tokens','Licensed Montserrat and Inter files, provenance, sRGB CSS/JSON and computed contrast records.'),
            ('source + references','Portable generation scripts and the preserved earlier MEAT guide. Rebuilt geometry is separate from the prior reference.'),
        ]
        for i,(path,desc) in enumerate(entries):
            top=193+i*77
            self.text(path,64,top,21,'charcoal','Bold')
            self.para(desc,386,top+1,806,17,24,'#55565E')
            if i<4:self.line(64,top+62,1216,top+62,'#CFCDCA')
        self.rect(64,588,1152,64,'charcoal',radius=10)
        self.label('HANDOFF',84,601,'coral',11)
        self.para('Use SVG for scalable artwork. Use PNG for fixed-size placement. Keep fonts with their licences. See README.md and asset-manifest.json for rebuild and inventory details.',
                  210,602,978,15,21,'paper')
        self.footer('V2.0 / PRIOR V1.0 REFERENCE PRESERVED / APPROVAL HISTORY UNRESOLVED')


def markdown_text():
    palette='\n'.join(f'| {PALETTE_ROLES[k][0]} | `{v}` | {" / ".join(str(i) for i in rgb(k))} | {PALETTE_ROLES[k][1]} |' for k,v in COLOURS.items())
    pairs='\n'.join(f'| {PALETTE_ROLES[fg][0]} on {PALETTE_ROLES[bg][0]} | {contrast(fg,bg):.2f}:1 | {"Pass" if contrast(fg,bg)>=4.5 else "Fail"} | {role} |' for fg,bg,role in PAIRINGS)
    fields='\n'.join(f'{i+1}. {label}' for i,label in enumerate(FIELD_LABELS))
    interests='\n\n'.join(f'### {group}\n\n'+', '.join(values)+'.' for group,values in INTEREST_GROUPS.items())
    return f'''# MEAT Brand Guide

**Version {VERSION} | {DATE} | Proposed refinement**

This is the complete textual counterpart to the thirteen-page landscape guide. The identity is MEAT. This edition aligns a recovered identity proposal with the rebuilt app direction and supplies usable production assets. It does not establish brand approval, trademark clearance, original vector recovery, independent age verification, or a live online service.

## 01. Cover: connection on your terms

The cover uses the supplied reversed production master: the MEAT name in uppercase with a coral slanted accent on Charcoal. "Connection. On your terms." is proposed communication copy, not a recovered permanent tagline. The full brand name is MEAT. NEXT may describe the preview edition outside the logo; it is not part of the production master.

## 02. Introduction: clear intentions, more possibility

The current MEAT preview centres on adults, particularly men seeking men in Perth. Desire, dating, friendship and community belong in the same conversation. The intended impression is confident, direct and warm, with room for users to describe themselves without forced labels.

### Evidence and decision status

| Element | Status in this edition |
|---|---|
| Exact name MEAT | Established by the user's request and recovered guide; retained uppercase. |
| Earlier MEAT app brand guide, version 1.0 | Recovered reference, preserved in `references/MEAT-app-brand-guide-prior.pdf`; its approval history is unknown. |
| Montserrat Black and Inter direction | Recovered from pages 3 and 9 of the earlier proposed guide; retained. |
| Earlier palette | Preserved in the reference: Ink #10090C, Merlot #26151C, Coral #FF5B67, Cream #FFF0EC and Rose #D9A7B4. |
| Current Charcoal, Coral, Lime, Paper, Panel and Muted tokens | Proposed v2 refinement matching the rebuilt app direction. |
| Slanted bar and current full signature | Proposed refinement of the app's existing visual accent. |
| Production SVG paths | Newly reconstructed artwork, not an extracted original master. |
| Plain compact M | Reconstructed from the prior compact direction; original vector not recovered. |
| Optional M / slash | Proposed additional companion; not the primary favicon. |
| Clear space and minimum sizes | Proposed rules for this supplied geometry, reviewed at reference size. |

The earlier guide described MEAT's context within a wider brand architecture. That reference is retained without using it to infer legal ownership or to impose other brands' fonts, colours or endorsements.

### The profile language

The upgraded app provides **15 optional profile groups, 32 interest choices and four interest stances**. These are the requested profile features implemented in the local preview, not evidence of a live member network.

{fields}

Every field is optional. An unspecified answer must stay unspecified. People may choose sex, romance, friendship or more than one motivation. The brand should not shame a person's choices or suggest that a preference is consent to an interaction.

## 03. The wordmark

Use **MEAT** in uppercase. Use **MEAT app** when the descriptor helps; `app` stays lowercase. Do not expand the name into an acronym. Use the provided SVG outlines for production rather than retyping the name, guessing the spacing or rebuilding the slanted accent.

Montserrat Black is documented in the recovered 1.0 guide. The new kit's outlined lettering is a reconstruction using sourced font software. It is not a claim that the original working font binary, kerning file or editable vector master was recovered.

The coral slanted bar follows the rebuilt app's visual direction and is a proposed addition to the earlier wordmark. It belongs to the complete signature: keep its geometry, spacing, proportion and colour from the supplied file. Do not detach it and invent a new lockup.

NEXT is an optional preview edition label only. If used, set it as separate descriptive text outside the logo's clear space. Do not add it to the production wordmark or rename the brand MEAT NEXT.

## 04. Logo versions

| Master | Appearance | Intended use |
|---|---|---|
| `logos/svg/meat-primary.svg` | Charcoal lettering with coral bar | Light surfaces |
| `logos/svg/meat-reversed.svg` | Paper lettering with coral bar | Dark surfaces |
| `logos/svg/meat-black.svg` | Solid black | Single-colour reproduction on light |
| `logos/svg/meat-white.svg` | Solid white | Single-colour reproduction on dark |
| `logos/svg/meat-wordmark-coral.svg` | Plain MEAT in Coral | Secondary continuity companion |
| `logos/svg/meat-mark-coral.svg` | Coral plain M | Dark compact placements |
| `logos/svg/meat-mark-charcoal.svg` | Charcoal compact companion | Light compact placements |
| `logos/svg/meat-mark-white.svg` | White plain M | Dark single-colour placements |
| `logos/svg/meat-mark-slash-reversed.svg` | Paper M with Coral slash | Optional compact secondary signature |

The earlier proposal used a coral wordmark. The two-colour v2 signatures are a declared refinement, not a retroactive claim that the prior proposal was approved or superseded by an earlier instruction. All supplied versions use consistent underlying geometry.

## 05. Clear space and minimum size

For the complete signature, let **x equal half the height of the capital M**. Keep an equal margin of x around every visible edge of the artwork, including the slanted bar. Measure from actual artwork bounds rather than the transparent canvas. Keep copy, crop edges, photographs and unrelated marks outside the clear space.

Proposed minimum screen sizes for these reconstructed assets:

| Variant | Minimum visible width | Condition |
|---|---|---|
| Full slash signature | 112 px | Use a larger version where the name needs more prominence. |
| Plain wordmark | 88 px | Continuity companion without the slash. |
| Plain compact M | 24 px | General compact use; add a MEAT label in unfamiliar contexts. |
| Optional M / slash | 32 px | Secondary compact signature, never the favicon. |
| Favicon | 16 px canvas | Specific inspected favicon exception; not a general logo minimum. |

The earlier guide proposed 88 px for its wordmark and 16 px for its simpler M. The full v2 signature minimum increases to 112 px for the additional slanted bar; the plain wordmark retains the 88 px reference minimum. The 24 px plain-M rule is a general-use proposal, separate from its 16 px favicon use. Native-size specimens in this guide use one PDF point as one reference pixel in a 72 dpi render. Final interface scaling, density and rendering still need inspection. No production print minimum is established in this edition; proof physical output with the supplier.

## 06. Misuse

Do not stretch or squash the signature. Do not rotate the whole master: retain the lean already drawn into the accent. Do not improvise colours, use a low-contrast version on the wrong ground, crowd the clear space, attach NEXT to the artwork, add an outline or shadow, redraw the wordmark, or introduce an unverified registration mark.

The PDF demonstrates incorrect stretching, rotation, colour, contrast, crowding and attached edition text using the actual supplied vectors. Those altered guide examples are instructional only and are not production assets.

## 07. Palette

The v2 palette is a proposed app-aligned refinement. Exact digital sRGB values are authoritative for this kit.

| Colour | Hex | RGB | Role |
|---|---|---|---|
{palette}

Keep Charcoal as the main ground and use Coral purposefully for identity and clear actions. Lime is a supporting accent; it must not imply that a person is verified, safe, available or consenting. Use words or symbols alongside colour so a choice, warning or state is not communicated by hue alone.

Paper and Panel create a calm hierarchy. Muted supports secondary text on dark backgrounds; important actions and essential content should remain prominent. No Pantone equivalence, press profile or CMYK guarantee is defined. The previous palette is retained inside the reference PDF for traceability.

## 08. Colour pairings

Calculated solid-token contrast ratios:

| Pair | Ratio | AA normal text | Intended use |
|---|---|---|---|
{pairs}

WCAG 2.2 AA requires at least 4.5:1 for normal text and 3:1 for qualifying large text. Threshold decisions use unrounded ratios. The table covers only these solid foreground/background pairs; it does not certify the brand, guide or interface as accessible. Opacity, gradients, photographs, focus treatments, font size, weight and actual UI states need their own checks. Avoid Paper on Coral and Coral on Paper for normal copy. A logo exception in the standard is not a reason to choose an unreadable placement.

Reference: [W3C Understanding SC 1.4.3: Contrast (Minimum)](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), consulted 17 October 2026. Full computed token records are supplied in `tokens/`.

## 09. Typography

Retain the earlier guide's pairing: **Montserrat Black** for short display statements and the wordmark; **Inter** for readable functional content. Use the real bundled font files and weights. Do not simulate bold, allow silent fallback in production artwork or assume that the original font binary was recovered.

| Role | Family and weight | Suggested size / line height | Example |
|---|---|---|---|
| Display | Montserrat Black, 900 | 56 / 60 px, adapted to placement | MAKE IT YOUR CALL. |
| Page heading | Inter Bold, 700 | 32 / 38 px | Your next connection. |
| Body | Inter Regular, 400 | 17 / 26 px | Say what you want. Share what feels right. |
| Control | Inter Bold, 700 | 15 / 20 px | Save preferences |
| Caption | Inter Medium, 500 | 12 / 18 px | Saved on this device. |

These are starting scales, not a requirement to shrink important text. Keep labels short, preserve natural reading order, and let content wrap instead of forcing text into narrow containers. The PDF uses larger presentation sizes where helpful. Font licences, provenance and supplied files live in `fonts/`; retain the licences when redistributing the font software. Production SVG lettering is outlined and does not need a font installation merely to display.

## 10. Icons

The plain compact M retains the direction from the earlier guide, with newly reconstructed production outlines. The M / slash is an optional additional companion with a 32 px minimum, not the primary app or favicon icon. Use the supplied transparent glyphs, opaque app tiles and favicon assets rather than independently recreating them. Keep the built-in padding in app tiles and avatars. In a new context, accompany the compact mark with the MEAT name until recognition is clear.

The proposed general compact minimum is 24 px visible width. The delivered 16 px favicon is a narrowly defined exception. Check native-size reductions, not enlarged previews alone. Do not use the full wordmark inside a small icon tile.

For maskable output, the background fills the square canvas and important foreground stays within the centred circle whose radius is 40% of the side. The kit supplies a separate transparent foreground so that this can be measured independently of the opaque tile. The circle drawn on the guide's specimen is instructional and is not in the finished export.

Reference: [W3C Web Application Manifest: icon masks](https://www.w3.org/TR/appmanifest/#icon-masks). Platform crop behaviour should be checked when the icon is installed in a particular product.

## 11. Applications

The PDF places the actual finished social files from this kit. It does not redraw their logos or substitute mock screenshots.

| File | Canvas | Purpose |
|---|---|---|
| `social/meat-open-graph-1200x630.png` | 1200 × 630 px | General link-preview artwork |
| `social/meat-banner-1500x500.png` | 1500 × 500 px | Reusable horizontal banner |
| `social/meat-square-1080x1080.png` | 1080 × 1080 px | Reusable square artwork |

These are practical reusable formats, not guarantees for every platform. Keep the important identity inside the destination's visible crop. Adapt campaign copy to the actual feature or event. Do not imply the artwork advertises a live member service when only the local preview is available. Do not place real people's portraits, endorsements or activity indicators without appropriate source and permission.

## 12. Voice and tone

**A clear yes. A kind no. Room to decide.**

MEAT's voice is direct about desire and clear about choice. Adult labels can be plain and non-graphic. Use the words that help people understand their own selections; avoid coy euphemism, pressure, fetishising labels or exaggerated confidence claims.

| Principle | Use | Avoid |
|---|---|---|
| Say it plainly | Casual sex; Go on dates; Friends with benefits | Vague claims that hide the actual choice |
| Leave room | Choose what feels like you. You can leave this blank. | Choose one or you cannot continue. |
| Name the boundary | Ask before explicit photos. | A preference treated as permission |
| Be specific about privacy | Saved on this device. | Private vault, anonymous or encrypted without evidence |
| Tell the product truth | Sample message - not sent. | Live chat or message delivered when no service exists |
| Describe the gate honestly | Adult self-declaration | Age verified without independent verification |

Interest stances are **Into it**, **Curious**, **Discuss first** and **Not for me**. None authorises a specific interaction. All fifteen profile groups remain optional. A person's role, relationship style, gender or curiosity should not be turned into a stereotype.

### The 32-interest vocabulary

Use the exact current catalogue labels where a product selection is intended. These are neutral profile vocabulary, not instructions or promises.

{interests}

### Current preview boundaries

The current implementation stores choices in the browser and uses fictional example profiles. Sharing controls demonstrate what a viewer could see; they do not publish a profile. Local sample conversation controls do not deliver messages to other people. Do not advertise live matching, member verification, emergency alerts, moderation response, secure encryption or real availability without separately implemented and verified services.

## 13. Asset kit and handoff

| Location | Contents |
|---|---|
| `logos/svg/` | Self-contained outlined production signatures and compact companions |
| `logos/png/` | Transparent raster logo exports at 512, 1024 and 2048 px canvas widths |
| `icons/` | Favicon, Apple touch icon, install icons, maskable tile and measurable foreground |
| `social/` | Finished link-preview, banner and square artwork |
| `fonts/` | Sourced font software, licences and provenance |
| `tokens/` | sRGB CSS/JSON and calculated solid-pair contrast |
| `source/` | Portable production scripts |
| `references/` | Preserved earlier MEAT app brand guide |
| `asset-manifest.json` | Machine-readable declared inventory |
| `MEAT_Brand_Guide.pdf` | Reviewed thirteen-page landscape guide |
| `MEAT_Brand_Guide.md` | This full textual counterpart |
| `README.md` | Usage, dependencies and rebuild instructions |

Use SVG for scalable production artwork and PNG for fixed-size placement. Match the chosen logo version to its ground. Preserve the complete kit's relative folder structure when rebuilding. Read `README.md` before regeneration. Keep every supplied font with its licence. Asset presence, format validation and visual review do not establish legal ownership, originality, trademark clearance or official brand approval.

### Sources used

1. `references/MEAT-app-brand-guide-prior.pdf`, version 1.0, October 2026: prior proposed typography, palette, naming and thirteen-page structure.
2. The supplied `MEAT_Profile_Selections_Upgrade.md`, version 1.0, 17 October 2026, and the rebuilt app's catalogue: fifteen optional groups, thirty-two interests, four stances and the current local-preview scope.
3. The current MEAT app reconstruction: Charcoal, Coral and Lime direction, uppercase name and slanted accent. This guide is not a source audit of the original hosted app.
4. W3C WCAG 2.2 contrast guidance and Web Application Manifest icon-mask guidance, linked above.
5. Bundled font provenance and licences in `fonts/` for the exact supplied software.
'''


def readme_text():
    return '''# MEAT brand kit

Version 2.0 - 17 October 2026 - proposed refinement.

## Start here

Open `MEAT_Brand_Guide.pdf` for the visual system or `MEAT_Brand_Guide.md` for the full text. Use `logos/svg/meat-primary.svg` on light surfaces and `logos/svg/meat-reversed.svg` on dark. Use the solid black or white versions for one-colour reproduction. Every production SVG is self-contained outlined artwork.

The name is **MEAT**. The kit retains the earlier proposed Montserrat and Inter direction. It introduces the rebuilt app's Charcoal/Coral/Lime direction and slanted accent as a proposed refinement. The earlier guide remains in `references/MEAT-app-brand-guide-prior.pdf`; original vector masters and approval history were not established. NEXT is optional descriptive preview-edition text, never part of the production logo.

## Files

- `logos/svg/`: production wordmarks and compact companions.
- `logos/png/`: matching transparent exports; named sizes refer to canvas widths.
- `icons/`: browser and app assets, with the separate maskable foreground.
- `social/`: final 1200×630, 1500×500 and 1080×1080 artwork.
- `fonts/`: the exact sourced font files, licences and provenance.
- `tokens/`: digital sRGB colours and calculated contrast pairs.
- `source/`: portable generation scripts.
- `asset-manifest.json`: declared inventory and expected properties.

Do not remove relative directories before rebuilding. The guide consumes the exact supplied SVG and social masters; it does not substitute separately drawn logo art. Do not use the intentionally incorrect examples from the guide as production artwork.

## Rebuild

Use Python 3.10 or newer in an isolated environment. Install the libraries used by the supplied builders:

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell alternative: .venv\\Scripts\\Activate.ps1
python -m pip install reportlab svglib Pillow fonttools PyMuPDF
python source/build_assets.py
python source/build_guide.py
```

`build_guide.py` has no network requirement. It resolves paths relative to itself and expects the supplied font files, production SVGs and social PNGs. `build_assets.py` uses PyMuPDF for raster exports. Font acquisition or outlining details are recorded in the asset source and font provenance. Preserve those source inputs and licences.

Optional guide geometry evidence:

```bash
python source/build_guide.py --review-dir ./guide-review
```

This creates a PDF geometry record and hash in the selected review directory. It does not claim visual review. To inspect the PDF, install Poppler and render all pages:

```bash
pdftoppm -r 90 -png MEAT_Brand_Guide.pdf guide-review/page
```

The expected PDF is **13 pages at 1280×720 points**. Read every page at a legible scale; a contact sheet is only a navigation aid. Verify exact lettering, minimum-size specimens, captions, typography weights and exports before releasing a rebuilt kit. The supplied reviewed guide need not be regenerated simply to use the logo assets.

## Production notes

The clear-space proposal is half the capital M height around the complete signature. The proposed slash-signature minimum is 112 px visible width, the plain-wordmark minimum is 88 px and general plain-M use starts at 24 px. The optional M / slash starts at 32 px; 16 px is a favicon-only exception. Screen specimens in the guide use a 72 dpi reference render. Physical output needs a supplier proof; no print or Pantone match is promised.

Use the exact sRGB tokens. Calculated text contrast applies only to the named solid pairs, not to photography, transparency, every UI state, or a complete accessibility assessment. Keep the actual font licences with any redistribution of font software. Do not infer trademark clearance or legal ownership from a generated brand kit.

## Product language

MEAT's upgraded local preview has fifteen optional profile groups, thirty-two interests and four stances. It uses fictional examples and browser-local state. Do not claim verified age, live chat, real nearby members, encrypted storage or a connected moderation service. A stated interest is a conversation starter, not consent.
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review-dir', type=Path)
    args = parser.parse_args()
    assert len(FIELD_LABELS) == 15
    assert sum(len(values) for values in INTEREST_GROUPS.values()) == 32
    for rel in list(LOGOS.values()) + list(SOCIAL.values()):
        require(rel)
    require('brand-brief.json')
    require('asset-manifest.json')
    brief = json.loads((KIT/'brand-brief.json').read_text())
    manifest = json.loads((KIT/'asset-manifest.json').read_text())
    declared_paths = {asset['path'] for asset in manifest.get('assets', [])}
    missing_declarations = set(LOGOS.values()) | set(SOCIAL.values())
    missing_declarations -= declared_paths
    if missing_declarations:
        raise ValueError(f'Guide references undeclared production assets: {sorted(missing_declarations)}')
    if brief.get('brand') not in ('MEAT','MEAT app'):
        raise ValueError('The supplied brief must identify MEAT.')
    # Palette equality is a release gate: do not silently illustrate different tokens.
    palette_values = {entry['hex'].upper() for entry in brief.get('palette', [])}
    if not set(COLOURS.values()).issubset(palette_values):
        raise ValueError('Guide palette and production brief do not agree.')
    names_by_hex = {entry['hex'].upper():entry['name'] for entry in brief.get('palette', [])}
    for key, value in COLOURS.items():
        PALETTE_ROLES[key] = (names_by_hex[value], PALETTE_ROLES[key][1])
    output = KIT/'MEAT_Brand_Guide.pdf'
    guide = Guide(output)
    guide.build()
    (KIT/'MEAT_Brand_Guide.md').write_text(markdown_text(), encoding='utf-8')
    (KIT/'README.md').write_text(readme_text(), encoding='utf-8')
    if args.review_dir:
        args.review_dir.mkdir(parents=True,exist_ok=True)
        outside = [box for box in guide.boxes if box['x'] < -.5 or box['top'] < -.5
                   or box['x']+box['width'] > W+.5 or box['top']+box['height'] > H+.5]
        record = {'guide':output.name,'pages':guide.page,'dimensions_pt':[W,H],
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'geometry_only':True,'visual_review':'not performed by this script',
                  'out_of_page_boxes':outside,'boxes':guide.boxes}
        (args.review_dir/'guide-geometry.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(json.dumps({'guide':str(output),'pages':guide.page,'dimensions_pt':[W,H],
                      'markdown':str(KIT/'MEAT_Brand_Guide.md'),'readme':str(KIT/'README.md')}))


if __name__ == '__main__':
    main()
