#!/usr/bin/env python3
"""Rebuild MEAT's proposed asset refinement from bundled, unmodified fonts.

Run: python source/build_assets.py
Dependencies: Python 3.10+, fonttools, PyMuPDF, Pillow. No network is used.
The guide is produced separately. Existing non-asset manifest entries are retained.
Text is outlined using actual glyphs plus the font's GPOS pair positioning.
The final wordmark uses an explicit -15/1000 em tracking refinement, not recovered
original logo coordinates. Production SVGs contain paths/shapes only.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import math
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

import fitz
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageFont

SOURCE_ROOT = Path(__file__).resolve().parents[1]
NS = 'http://www.w3.org/2000/svg'
CAP_HEIGHT = 1000.0
PNG_WIDTHS = (512, 1024, 2048)
PALETTE = {
    'charcoal': '#0E1014', 'coral-pink': '#FF6389', 'soft-lime': '#B7DFA5',
    'paper': '#F5F3F0', 'slate': '#9C9DA9', 'panel': '#17191F',
    'black': '#000000', 'white': '#FFFFFF',
}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def build_colour_tokens(root, brief):
    """Portable token rebuild, independently verified by the skill helper.

    Ratios are computed from solid sRGB pairs with the WCAG 2.2 transfer
    function; decisions use the unrounded values. Artwork is not certified.
    """
    colours = {}
    for entry in brief['palette']:
        value = entry['hex'].upper()
        colours[entry['id']] = {
            'name': entry['name'], 'hex': value,
            'rgb': [int(value[i:i+2], 16) for i in (1, 3, 5)],
            'role': entry['role'], 'status': entry['status'],
        }
    def luminance(colour):
        values = [channel / 255 for channel in colour['rgb']]
        linear = [v / 12.92 if v <= 0.04045 else ((v+.055)/1.055)**2.4 for v in values]
        return sum(v*w for v,w in zip(linear, (.2126, .7152, .0722)))
    pairs = []
    for spec in brief['contrast_pairs']:
        high, low = sorted([luminance(colours[spec[key]]) for key in ['foreground', 'background']], reverse=True)
        ratio = (high+.05)/(low+.05)
        pairs.append({**spec, 'ratio': ratio, 'ratio_display': f'{ratio:.2f}:1',
                      'aa_normal_text': ratio >= 4.5, 'aa_large_text': ratio >= 3})
    write_json(root/'tokens/colours.json', {
        'schema_version': 1, 'brand': 'MEAT', 'colour_space': 'sRGB',
        'prefix': 'meat', 'colours': colours,
    })
    write_json(root/'tokens/contrast.json', {
        'schema_version': 1, 'brand': 'MEAT',
        'scope': 'Solid sRGB foreground/background pairs only',
        'thresholds': {'aa_normal_text': 4.5, 'aa_large_text': 3.0},
        'notes': [
            'Pass flags use the unrounded ratio. Display rounding does not change a result.',
            'Large-text flags apply only to text meeting the relevant size/weight definition.',
            'These pair results do not certify an artwork, guide, website or application.',
        ],
        'source': 'https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html',
        'pairs': pairs,
    })
    css = ':root {\n' + ''.join(f'  --meat-{key}: {value["hex"]};\n' for key,value in colours.items()) + '}\n'
    (root/'tokens/colours.css').write_text(css)


def f(value):
    return f'{value:.6f}'.rstrip('0').rstrip('.')


@dataclass
class Geometry:
    content: str
    width: float
    height: float

    def placed(self, x, y, width=None, height=None):
        scale = width / self.width if width is not None else height / self.height
        return f'<g transform="translate({f(x)} {f(y)}) scale({f(scale)})">{self.content}</g>'


class Outliner:
    def __init__(self, path):
        self.font = TTFont(path)
        self.glyphs = self.font.getGlyphSet()
        self.cmap = self.font.getBestCmap()
        self.upem = self.font['head'].unitsPerEm
        self.cap = self.font['OS/2'].sCapHeight
        self.pair_tables = []
        if 'GPOS' in self.font:
            table = self.font['GPOS'].table
            indices = set()
            for feature in table.FeatureList.FeatureRecord:
                if feature.FeatureTag == 'kern':
                    indices.update(feature.Feature.LookupListIndex)
            for index in sorted(indices):
                lookup = table.LookupList.Lookup[index]
                for sub in lookup.SubTable:
                    lookup_type = lookup.LookupType
                    if lookup_type == 9:
                        lookup_type, sub = sub.ExtensionLookupType, sub.ExtSubTable
                    if lookup_type == 2:
                        self.pair_tables.append(sub)

    def kern(self, left, right):
        if left is None:
            return 0
        advance = 0
        for sub in self.pair_tables:
            if left not in sub.Coverage.glyphs:
                continue
            if sub.Format == 1:
                records = sub.PairSet[sub.Coverage.glyphs.index(left)].PairValueRecord
                match = next((p for p in records if p.SecondGlyph == right), None)
                if match and match.Value1:
                    advance += getattr(match.Value1, 'XAdvance', 0) or 0
            elif sub.Format == 2:
                a = sub.ClassDef1.classDefs.get(left, 0)
                b = sub.ClassDef2.classDefs.get(right, 0)
                record = sub.Class1Record[a].Class2Record[b]
                if record.Value1:
                    advance += getattr(record.Value1, 'XAdvance', 0) or 0
        return advance

    def text(self, text, fill, cap_height=1000, tracking_em=0):
        cursor = 0
        previous = None
        path = SVGPathPen(self.glyphs)
        bounds = BoundsPen(self.glyphs)
        for character in text:
            glyph = self.cmap.get(ord(character))
            if glyph is None:
                raise ValueError(f'Font does not contain {character!r}')
            cursor += self.kern(previous, glyph)
            transform = (1, 0, 0, 1, cursor, 0)
            self.glyphs[glyph].draw(TransformPen(path, transform))
            self.glyphs[glyph].draw(TransformPen(bounds, transform))
            cursor += self.font['hmtx'].metrics[glyph][0] + tracking_em * self.upem
            previous = glyph
        x0, y0, x1, y1 = bounds.bounds
        scale = cap_height / self.cap
        data = path.getCommands()
        content = f'<path fill="{fill}" d="{data}" transform="matrix({f(scale)} 0 0 {f(-scale)} {f(-x0*scale)} {f(y1*scale)})"/>'
        return Geometry(content, (x1-x0)*scale, (y1-y0)*scale)


def svg(geometry, title, description='Proposed MEAT production refinement; lettering is outlined.'):
    return f'<svg xmlns="{NS}" width="{f(geometry.width)}" height="{f(geometry.height)}" viewBox="0 0 {f(geometry.width)} {f(geometry.height)}"><title>{html.escape(title)}</title><desc>{html.escape(description)}</desc>{geometry.content}</svg>\n'


def render_svg(path, output, width=None, height=None):
    document = fitz.open(path)
    page = document[0]
    scale = width / page.rect.width if width else height / page.rect.height if height else 1
    pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=True)
    image = Image.frombytes('RGBA', (pixmap.width, pixmap.height), pixmap.samples)
    target = (width or round(page.rect.width*scale), height or math.ceil(page.rect.height*scale))
    if image.size != target:
        image = image.resize(target, Image.Resampling.LANCZOS)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Keep interrupted writes and parallel readers from seeing a truncated PNG.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=output.stem+'-', suffix='.png', delete=False) as handle:
            temporary = Path(handle.name)
            image.save(handle, format='PNG')
        temporary.replace(output)
    finally:
        if temporary and temporary.exists():
            temporary.unlink()
    return image


def signature(word, slash_colour):
    # A 10.2-degree forward leaning bar: original geometry, not recovered.
    slash = f'<path fill="{slash_colour}" d="M180 0H410L230 1000H0Z"/>'
    return Geometry(slash + word.placed(620, 0, height=1000), 620 + word.width, 1000)


def rect(x, y, width, height, colour, radius=0):
    return f'<rect x="{f(x)}" y="{f(y)}" width="{f(width)}" height="{f(height)}" rx="{f(radius)}" fill="{colour}"/>'


def icon_geometry(mark, size=512, background=None, fraction=.62):
    scale = size*fraction/max(mark.width, mark.height)
    width, height = mark.width*scale, mark.height*scale
    body = rect(0, 0, size, size, background) if background else ''
    body += mark.placed((size-width)/2, (size-height)/2, width=width)
    return Geometry(body, size, size)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=SOURCE_ROOT)
    args = parser.parse_args()
    root = args.out.resolve()
    root.mkdir(parents=True, exist_ok=True)
    for directory in ['logos/svg', 'logos/png', 'logos/review', 'icons', 'social', 'tokens', 'fonts']:
        (root/directory).mkdir(parents=True, exist_ok=True)
    font_files = ['Montserrat-Black.ttf', 'Inter-Regular.ttf', 'Inter-Medium.ttf', 'Inter-Bold.ttf',
                  'OFL-Montserrat.txt', 'OFL-Inter.txt', 'font-provenance.json']
    if root != SOURCE_ROOT:
        for name in font_files:
            shutil.copy2(SOURCE_ROOT/'fonts'/name, root/'fonts'/name)
    display = Outliner(root/'fonts/Montserrat-Black.ttf')
    body_font = Outliner(root/'fonts/Inter-Regular.ttf')
    bold_font = Outliner(root/'fonts/Inter-Bold.ttf')

    brief_path = root/'brand-brief.json'
    brief = json.loads(brief_path.read_text()) if brief_path.exists() else {}
    brief.update({
        'schema_version': 1, 'brand': 'MEAT', 'slug': 'meat', 'mode': 'refinement',
        'identity_status': 'proposed refinement of a recovered proposed identity',
        'exact_display_name': 'MEAT',
        'palette': [{'id': key, 'name': key.replace('-', ' ').title(), 'hex': value,
                     'role': {'charcoal':'Primary dark ground','coral-pink':'Signature accent',
                              'soft-lime':'Limited secondary emphasis','paper':'Primary light text and light ground',
                              'slate':'Supporting text on dark','panel':'Panel surface','black':'Single-colour reproduction',
                              'white':'Single-colour reproduction'}[key],
                     'status':'proposed app-aligned refinement'} for key,value in PALETTE.items()],
        'contrast_pairs': [
            {'foreground':'paper','background':'charcoal','use':'Primary text on dark'},
            {'foreground':'charcoal','background':'paper','use':'Primary text on light'},
            {'foreground':'coral-pink','background':'charcoal','use':'Accent text on dark'},
            {'foreground':'charcoal','background':'coral-pink','use':'Primary button label'},
            {'foreground':'slate','background':'charcoal','use':'Secondary text on dark'},
            {'foreground':'soft-lime','background':'charcoal','use':'Limited secondary emphasis'},
            {'foreground':'white','background':'coral-pink','use':'Avoid for ordinary text; check ratio'},
        ],
        'typography': [
            {'family':'Montserrat','weight':900,'style':'Black','path':'fonts/Montserrat-Black.ttf','role':'Outlined wordmark and short display lines','status':'Typeface recovered from prior proposed guide; geometry rebuilt'},
            {'family':'Inter','weight':400,'style':'Regular','path':'fonts/Inter-Regular.ttf','role':'Body and form copy','status':'Typeface recovered from prior proposed guide'},
            {'family':'Inter','weight':500,'style':'Medium','path':'fonts/Inter-Medium.ttf','role':'Captions and labels','status':'Typeface recovered from prior proposed guide'},
            {'family':'Inter','weight':700,'style':'Bold','path':'fonts/Inter-Bold.ttf','role':'Headings and actions','status':'Typeface recovered from prior proposed guide'},
        ],
        'sources': [
            {'path':'references/MEAT-app-brand-guide-prior.pdf','status':'Recovered prior proposal; approval unknown','evidence':'13-page October 2026 guide: Montserrat Black, Inter, uppercase MEAT and compact M'},
            {'path':'references/app-brand-tokens.json','status':'Snapshot of observed app implementation; not prior brand approval','evidence':'Charcoal #0E1014, coral pink #FF6389, soft lime #B7DFA5, supporting app tokens and slanted bar'},
            {'path':'fonts/font-provenance.json','status':'Verified downloaded font metadata and checksums','evidence':'Unmodified official Montserrat and Inter static font files with original OFL 1.1 licences'},
        ],
        'decisions': [
            {'element':'Name','status':'established','decision':'Always MEAT; app is an optional lowercase descriptor. NEXT is a preview edition label only.'},
            {'element':'Lettering','status':'refined','decision':'Rebuilt Montserrat Black outlines with GPOS kerning and -0.015 em tracking. Not exact recovered logo vectors.'},
            {'element':'Slash signature','status':'proposed','decision':'Forward leaning coral bar precedes MEAT; preserve as one supplied lockup.'},
            {'element':'Compact mark','status':'recovered concept; rebuilt vector','decision':'Use the plain Montserrat Black M for the primary small mark and favicons. Optional M/slash is secondary.'},
            {'element':'Palette','status':'refined','decision':'Use the new app palette; prior guide palette is retained as reference, not silently treated as approved or deleted.'},
        ],
        'deliverables': {'logo_png_widths':list(PNG_WIDTHS),'social_sizes':[[1200,630],[1500,500],[1080,1080]],'include_rebuild_sources':True},
        'recovered_prior_palette': {'Ink':'#10090C','Merlot':'#26151C','Coral':'#FF5B67','Cream':'#FFF0EC','Rose':'#D9A7B4'},
        'minimum_sizes': {'signature_visible_width_px':112,'plain_wordmark_visible_width_px':88,'plain_m_general_visible_width_px':24,'plain_m_favicon_canvas_px':16,'optional_m_slash_visible_width_px':32,'print':'Screen proposals inspected; print minima require a physical proof.'},
        'clear_space': {'unit':'Cap height H = 1000 design units','margin_each_side':500,'rule':'0.5H on every side of a visible signature, wordmark or standalone mark. Icons use their supplied tile padding.'},
    })

    words = {key: display.text('MEAT', value, tracking_em=-.015) for key,value in PALETTE.items()}
    marks = {key: display.text('M', value) for key,value in PALETTE.items()}
    masters = {
        'meat-primary': signature(words['charcoal'], PALETTE['coral-pink']),
        'meat-reversed': signature(words['paper'], PALETTE['coral-pink']),
        'meat-black': signature(words['black'], PALETTE['black']),
        'meat-white': signature(words['white'], PALETTE['white']),
        'meat-wordmark-coral': words['coral-pink'],
        'meat-wordmark-white': words['white'],
        'meat-mark-coral': marks['coral-pink'],
        'meat-mark-charcoal': marks['charcoal'],
        'meat-mark-white': marks['white'],
        'meat-mark-black': marks['black'],
        'meat-mark-slash-reversed': signature(marks['paper'], PALETTE['coral-pink']),
    }
    assets = []
    def add(path, kind, role, **checks):
        assets.append({'path':path,'kind':kind,'role':role,**checks})
    geometry_record = {}
    for stem, geometry in masters.items():
        source = root/f'logos/svg/{stem}.svg'
        source.write_text(svg(geometry, f'MEAT — {stem.removeprefix("meat-").replace("-"," ")}'))
        add(str(source.relative_to(root)), 'svg', 'outlined_logo', width=geometry.width, height=geometry.height, vector_required=True)
        rasters = {}
        for width in PNG_WIDTHS:
            output = root/f'logos/png/{stem}-{width}.png'
            image = render_svg(source, output, width=width)
            bounds = image.getchannel('A').getbbox()
            rasters[str(width)] = {'canvas':[image.width,image.height],'alpha_bounds':list(bounds), 'visible_width':bounds[2]-bounds[0], 'visible_height':bounds[3]-bounds[1]}
            add(str(output.relative_to(root)), 'png', 'transparent_logo', width=image.width, height=image.height, transparent=True)
        geometry_record[stem] = {'view_box':[0,0,geometry.width,geometry.height], 'visible_vector_bounds':[0,0,geometry.width,geometry.height], 'cap_height_units':CAP_HEIGHT, 'rasters':rasters}
    brief['geometry'] = geometry_record
    write_json(brief_path, brief)
    build_colour_tokens(root, brief)

    # Favicon retains the simpler recovered M concept, with no slash.
    favicon = icon_geometry(marks['coral-pink'], 64, PALETTE['charcoal'], fraction=.70)
    favicon_path = root/'icons/favicon.svg'
    favicon_path.write_text(svg(favicon, 'MEAT favicon — plain M'))
    add('icons/favicon.svg', 'svg', 'favicon', width=64,height=64,vector_required=True)
    favicon_images = {}
    for size in [16,32,48]:
        name = f'icons/favicon-{size}.png'
        favicon_images[size] = render_svg(favicon_path, root/name, width=size,height=size)
        add(name, 'png', 'favicon',width=size,height=size,transparent=False)
    favicon_images[48].save(root/'icons/favicon.ico', format='ICO', sizes=[(16,16),(32,32),(48,48)])
    add('icons/favicon.ico','ico','favicon',width=48,height=48,transparent=False)

    tile_specs = [
        ('apple-touch-icon-180',180,PALETTE['charcoal'],marks['coral-pink'],.62),
        ('icon-192',192,PALETTE['charcoal'],marks['coral-pink'],.62),
        ('icon-512',512,PALETTE['charcoal'],marks['coral-pink'],.62),
        ('icon-light-512',512,PALETTE['paper'],marks['charcoal'],.62),
        ('maskable-512',512,PALETTE['charcoal'],marks['coral-pink'],.54),
        ('maskable-foreground-512',512,None,marks['coral-pink'],.54),
    ]
    for stem,size,background,mark,fraction in tile_specs:
        geometry = icon_geometry(mark,size,background,fraction)
        source = root/f'icons/{stem}.svg'
        source.write_text(svg(geometry, f'MEAT — {stem}'))
        add(str(source.relative_to(root)), 'svg', 'icon_geometry',width=size,height=size,vector_required=True)
        output = root/f'icons/{stem}.png'
        render_svg(source, output, width=size,height=size)
        assertions = {'maskable':True,'foreground_path':'icons/maskable-foreground-512.png','safe_radius_ratio':.4} if stem=='maskable-512' else {}
        add(str(output.relative_to(root)), 'png','maskable_foreground' if background is None else 'app_icon',width=size,height=size,transparent=background is None,**assertions)
    integration = {'name':'MEAT','short_name':'MEAT','start_url':'../','scope':'../','display':'standalone','background_color':PALETTE['charcoal'],'theme_color':PALETTE['charcoal'],'icons':[
        {'src':'./icon-192.png','sizes':'192x192','type':'image/png','purpose':'any'},
        {'src':'./icon-512.png','sizes':'512x512','type':'image/png','purpose':'any'},
        {'src':'./maskable-512.png','sizes':'512x512','type':'image/png','purpose':'maskable'},
    ]}
    write_json(root/'icons/app-manifest.example.webmanifest', integration)
    (root/'icons/head-snippet.html').write_text('<!-- For a host page one directory above icons/. This is an integration example. -->\n<link rel="icon" href="icons/favicon.svg" type="image/svg+xml">\n<link rel="alternate icon" href="icons/favicon.ico" sizes="16x16 32x32 48x48">\n<link rel="apple-touch-icon" href="icons/apple-touch-icon-180.png" sizes="180x180">\n<link rel="manifest" href="icons/app-manifest.example.webmanifest">\n<meta name="theme-color" content="#0E1014">\n')
    add('icons/app-manifest.example.webmanifest','file','integration_example')
    add('icons/head-snippet.html','file','integration_example')

    # All social layouts place exact signature/mark masters; copy is separately outlined.
    def line(text, x, y, cap, colour, bold=False, tracking=0):
        geometry = (bold_font if bold else body_font).text(text,colour,cap,tracking)
        return geometry.placed(x,y,width=geometry.width)
    def centered_line(text, canvas_width, y, cap, colour, bold=False, tracking=0):
        geometry = (bold_font if bold else body_font).text(text,colour,cap,tracking)
        return geometry.placed((canvas_width-geometry.width)/2,y,width=geometry.width)
    social_specs = []
    content = rect(0,0,1200,630,PALETTE['charcoal'])
    content += rect(940,-160,340,940,PALETTE['panel'])
    content += '<path fill="#FF6389" d="M1090 0H1170L1040 630H960Z"/>'
    content += line('MEN SEEKING MEN · PERTH · 18+',84,48,11,PALETTE['slate'],True,.08)
    content += masters['meat-reversed'].placed(84,145,width=770)
    content += line('Connection on your terms.',86,399,31,PALETTE['paper'],True)
    content += line('Clear intentions. Room to be yourself.',86,458,15,PALETTE['slate'])
    content += f'<circle cx="90" cy="555" r="6" fill="{PALETTE["soft-lime"]}"/>'
    content += line('YOUR SPACE. YOUR PACE.',110,548,10,PALETTE['paper'],True,.06)
    social_specs.append(('meat-open-graph-1200x630',Geometry(content,1200,630)))

    content = rect(0,0,1500,500,PALETTE['coral-pink'])
    content += masters['meat-black'].placed(70,141,width=670)
    content += rect(812,98,2,304,PALETTE['charcoal'])
    content += line('Clear intentions.',872,158,27,PALETTE['charcoal'],True)
    content += line('Better connections.',872,212,27,PALETTE['charcoal'],True)
    content += line('MEAT · MEN SEEKING MEN · 18+',873,310,10,PALETTE['charcoal'],True,.07)
    social_specs.append(('meat-banner-1500x500',Geometry(content,1500,500)))

    content = rect(0,0,1080,1080,PALETTE['charcoal'])
    content += rect(54,54,972,972,PALETTE['panel'],32)
    content += line('YOUR SPACE. YOUR PACE.',95,101,13,PALETTE['slate'],True,.07)
    m=marks['coral-pink']
    content += m.placed((1080-300)/2,250,width=300)
    content += masters['meat-reversed'].placed(164,650,width=752)
    content += centered_line('Connection on your terms.',1080,900,25,PALETTE['paper'],True)
    content += centered_line('MEN SEEKING MEN · 18+',1080,960,10,PALETTE['slate'],True,.08)
    social_specs.append(('meat-square-1080x1080',Geometry(content,1080,1080)))
    for stem,geometry in social_specs:
        source=root/f'social/{stem}.svg'; source.write_text(svg(geometry,f'MEAT — {stem}','Reusable proposed social artwork. No live feature or endorsement claim.'))
        add(str(source.relative_to(root)),'svg','social_vector',width=int(geometry.width),height=int(geometry.height),vector_required=True)
        output=root/f'social/{stem}.png'; render_svg(source,output,width=int(geometry.width),height=int(geometry.height))
        add(str(output.relative_to(root)),'png','social',width=int(geometry.width),height=int(geometry.height),transparent=False)

    # Explicit screen proofs. Labels refer to visible artwork width, not padded canvases.
    review_font=ImageFont.truetype(str(root/'fonts/Inter-Regular.ttf'),16)
    heading_font=ImageFont.truetype(str(root/'fonts/Inter-Bold.ttf'),22)
    contact=Image.new('RGB',(1600,1270),'#24252C'); draw=ImageDraw.Draw(contact)
    draw.text((38,28),'MEAT / proposed production refinement',font=heading_font,fill=PALETTE['paper'])
    cards=[('meat-reversed',PALETTE['charcoal']),('meat-primary',PALETTE['paper']),('meat-black','#FFFFFF'),('meat-white','#000000')]
    for index,(stem,bg) in enumerate(cards):
        x=38+(index%2)*780; y=84+(index//2)*240
        draw.rounded_rectangle((x,y,x+744,y+214),18,fill=bg)
        artwork=Image.open(root/f'logos/png/{stem}-1024.png'); artwork.thumbnail((648,132),Image.Resampling.LANCZOS)
        contact.paste(artwork,(x+(744-artwork.width)//2,y+35),artwork)
        draw.text((x+24,y+175),stem,font=review_font,fill='#777784' if bg in [PALETTE['paper'],'#FFFFFF'] else PALETTE['slate'])
    for index,name in enumerate(['icon-512','icon-light-512','maskable-512']):
        image=Image.open(root/f'icons/{name}.png').resize((152,152),Image.Resampling.LANCZOS)
        x=38+index*245; contact.paste(image,(x,596),image); draw.text((x,760),name,font=review_font,fill=PALETTE['paper'])
    x=840
    for size in [16,24,32,48,64]:
        image=render_svg(favicon_path,root/f'logos/review/plain-m-{size}.png',width=size,height=size)
        contact.paste(image,(x,625),image); draw.text((x,704),f'{size}px',font=review_font,fill=PALETTE['paper']);x+=130
    for index,(stem,geometry) in enumerate(social_specs):
        image=Image.open(root/f'social/{stem}.png'); image.thumbnail((470,395),Image.Resampling.LANCZOS)
        x=38+index*525; contact.paste(image,(x,833),image)
    contact.save(root/'logos/asset-contact-sheet.png')
    add('logos/asset-contact-sheet.png','png','asset_review',width=1600,height=1270,transparent=False)

    proof=Image.new('RGB',(1320,620),PALETTE['charcoal']);pd=ImageDraw.Draw(proof)
    pd.text((30,25),'Native-size proofs / actual visible artwork widths',font=heading_font,fill=PALETTE['paper'])
    for index,(stem,width,label) in enumerate([('meat-reversed',112,'Slash signature / 112px'),('meat-wordmark-coral',88,'Plain wordmark / 88px'),('meat-mark-slash-reversed',32,'Optional M + slash / 32px')]):
        image=render_svg(root/f'logos/svg/{stem}.svg',root/f'logos/review/{stem}-minimum.png',width=width)
        x=30+index*440; proof.paste(image,(x,95),image)
        pd.text((x,158),label,font=review_font,fill=PALETTE['paper'])
        enlarged=image.resize((image.width*3,image.height*3),Image.Resampling.NEAREST)
        proof.paste(enlarged,(x,220),enlarged)
    for index,size in enumerate([16,32,48]):
        image=favicon_images[size]; x=30+index*440
        proof.paste(image,(x,400),image); pd.text((x,556),f'Favicon / {size}px native at left; 3× at right',font=ImageFont.truetype(str(root/'fonts/Inter-Regular.ttf'),12),fill=PALETTE['slate'])
        enlarged=image.resize((size*3,size*3),Image.Resampling.NEAREST);proof.paste(enlarged,(x+180,382),enlarged)
    proof.save(root/'logos/small-size-proof.png')
    add('logos/small-size-proof.png','png','asset_review',width=1320,height=620,transparent=False)
    render_svg(root/'logos/svg/meat-mark-coral.svg', root/'logos/review/meat-mark-coral-minimum.png', width=24)

    # CSS uses relative bundled fonts; no cross-origin requests are introduced.
    font_css='\n'.join(f'@font-face{{font-family:"{family}";src:url("../fonts/{name}") format("truetype");font-style:normal;font-weight:{weight};font-display:swap;}}' for family,name,weight in [('Montserrat','Montserrat-Black.ttf',900),('Inter','Inter-Regular.ttf',400),('Inter','Inter-Medium.ttf',500),('Inter','Inter-Bold.ttf',700)])
    (root/'tokens/typography.css').write_text(font_css+'\n:root{--meat-font-display:"Montserrat",sans-serif;--meat-font-ui:"Inter",sans-serif;}\n')
    write_json(root/'tokens/build-dependencies.json',{'python':'>=3.10','packages':['fonttools','PyMuPDF','Pillow'],'command':'python source/build_assets.py','inputs':['brand-brief.json','fonts/Montserrat-Black.ttf','fonts/Inter-Regular.ttf','fonts/Inter-Medium.ttf','fonts/Inter-Bold.ttf'],'network_required':False,'font_licenses':['fonts/OFL-Montserrat.txt','fonts/OFL-Inter.txt'],'note':'Logo, icon, social and colour/font tokens rebuild offline. Brand guide generation is a separate builder. Skill audit helpers independently validate declared outputs.'})
    add('tokens/typography.css','file','typography_tokens')
    add('tokens/build-dependencies.json','file','rebuild_dependencies')
    add('fonts/font-provenance.json','file','font_provenance')
    add('fonts/OFL-Montserrat.txt','file','font_license')
    add('fonts/OFL-Inter.txt','file','font_license')
    add('brand-brief.json','file','brand_brief')
    if (root/'source/build_assets.py').exists():
        add('source/build_assets.py','file','portable_rebuild_source')
    for name in ['colours.css','colours.json','contrast.json']:
        if (root/'tokens'/name).exists():
            add('tokens/'+name,'file','colour_tokens')
    if (root/'tokens/asset-visual-review.json').exists():
        add('tokens/asset-visual-review.json','file','asset_visual_review')
    if (root/'tokens/portable-rebuild-check.json').exists():
        add('tokens/portable-rebuild-check.json','file','portable_rebuild_review')
    manifest_path=root/'asset-manifest.json'
    old=json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    owned_prefixes=('logos/','icons/','social/','fonts/','tokens/')
    retained=[a for a in old.get('assets',[]) if not a['path'].startswith(owned_prefixes) and a['path'] not in ['brand-brief.json','source/build_assets.py']]
    fonts=[{'path':'fonts/'+name,'license_path':'fonts/'+('OFL-Montserrat.txt' if name.startswith('Montserrat') else 'OFL-Inter.txt')} for name in ['Montserrat-Black.ttf','Inter-Regular.ttf','Inter-Medium.ttf','Inter-Bold.ttf']]
    manifest={'schema_version':1,'brand':'MEAT','assets':assets+retained,'fonts':fonts,'visual_review':{'status':'pending'}}
    write_json(manifest_path,manifest)
    print(json.dumps({'assets':len(assets),'retained':len(retained),'signature_bounds':geometry_record['meat-reversed']['view_box'],'wordmark_bounds':geometry_record['meat-wordmark-coral']['view_box'],'compact_bounds':geometry_record['meat-mark-coral']['view_box'],'root':str(root)},indent=2))


if __name__ == '__main__':
    main()
