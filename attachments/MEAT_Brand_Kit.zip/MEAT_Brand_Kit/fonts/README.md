# MEAT font files

The kit contains the following unmodified upstream TrueType files. The logo SVGs use outlined paths and do not require fonts to display.

| File | Weight | Intended use | Licence |
| --- | --- | --- | --- |
| `Montserrat-Black.ttf` | 900 | Wordmark source and display headings | `OFL-Montserrat.txt` |
| `Inter-Regular.ttf` | 400 | Body text and supporting copy | `OFL-Inter.txt` |
| `Inter-Medium.ttf` | 500 | Controls, labels and navigation | `OFL-Inter.txt` |
| `Inter-Bold.ttf` | 700 | Emphasis and section headings | `OFL-Inter.txt` |

`font-provenance.json` records the exact upstream URLs, Montserrat commit, Inter release, archive members and SHA-256 hashes. Preserve the original licence files with any redistribution of the font software. Read the licences for their terms; this guide does not replace them.

The supplied asset and guide builders load these relative paths and work offline after their Python dependencies are installed. Browser usage is provided in `../tokens/typography.css`.

Upstream projects: [Montserrat](https://github.com/JulietaUla/Montserrat) and [Inter](https://github.com/rsms/inter).
