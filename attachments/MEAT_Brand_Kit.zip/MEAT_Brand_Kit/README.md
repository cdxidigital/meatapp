# MEAT brand kit

Version 2.0 - 17 October 2026 - proposed refinement.

## Start here

Open `MEAT_Brand_Guide.pdf` for the visual system or `MEAT_Brand_Guide.md` for the full text. Use `logos/svg/meat-primary.svg` on light surfaces and `logos/svg/meat-reversed.svg` on dark. Use the solid black or white versions for one-colour reproduction. Every production SVG is self-contained outlined artwork.

The name is **MEAT**. The kit retains the earlier proposed Montserrat and Inter direction. It introduces the rebuilt app's Charcoal/Coral/Lime direction and slanted accent as a proposed refinement. The earlier guide remains in `references/MEAT-app-brand-guide-prior.pdf`; original vector masters and approval history were not established. NEXT is optional descriptive preview-edition text, never part of the production logo.

## Files

- `logos/svg/`: production wordmarks and compact companions.
- `logos/png/`: matching transparent exports; named sizes refer to canvas widths.
- `icons/`: browser and app assets, with the separate maskable foreground.
- `social/`: final 1200×630, 1500×500 and 1080×1080 artwork.
- `fonts/`: the exact sourced font files, licences and provenance.
- `tokens/`: digital sRGB colours and calculated contrast pairs.
- `source/`: portable generation scripts.
- `asset-manifest.json`: declared inventory and expected properties.

Do not remove relative directories before rebuilding. The guide consumes the exact supplied SVG and social masters; it does not substitute separately drawn logo art. Do not use the intentionally incorrect examples from the guide as production artwork.

## Rebuild

Use Python 3.10 or newer in an isolated environment. Install the libraries used by the supplied builders:

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell alternative: .venv\Scripts\Activate.ps1
python -m pip install reportlab svglib Pillow fonttools PyMuPDF
python source/build_assets.py
python source/build_guide.py
```

`build_guide.py` has no network requirement. It resolves paths relative to itself and expects the supplied font files, production SVGs and social PNGs. `build_assets.py` uses PyMuPDF for raster exports. Font acquisition or outlining details are recorded in the asset source and font provenance. Preserve those source inputs and licences.

Optional guide geometry evidence:

```bash
python source/build_guide.py --review-dir ./guide-review
```

This creates a PDF geometry record and hash in the selected review directory. It does not claim visual review. To inspect the PDF, install Poppler and render all pages:

```bash
pdftoppm -r 90 -png MEAT_Brand_Guide.pdf guide-review/page
```

The expected PDF is **13 pages at 1280×720 points**. Read every page at a legible scale; a contact sheet is only a navigation aid. Verify exact lettering, minimum-size specimens, captions, typography weights and exports before releasing a rebuilt kit. The supplied reviewed guide need not be regenerated simply to use the logo assets.

## Production notes

The clear-space proposal is half the capital M height around the complete signature. The proposed slash-signature minimum is 112 px visible width, the plain-wordmark minimum is 88 px and general plain-M use starts at 24 px. The optional M / slash starts at 32 px; 16 px is a favicon-only exception. Screen specimens in the guide use a 72 dpi reference render. Physical output needs a supplier proof; no print or Pantone match is promised.

Use the exact sRGB tokens. Calculated text contrast applies only to the named solid pairs, not to photography, transparency, every UI state, or a complete accessibility assessment. Keep the actual font licences with any redistribution of font software. Do not infer trademark clearance or legal ownership from a generated brand kit.

## Product language

MEAT's upgraded local preview has fifteen optional profile groups, thirty-two interests and four stances. It uses fictional examples and browser-local state. Do not claim verified age, live chat, real nearby members, encrypted storage or a connected moderation service. A stated interest is a conversation starter, not consent.
