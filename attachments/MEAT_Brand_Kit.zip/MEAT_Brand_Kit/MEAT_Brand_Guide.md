# MEAT Brand Guide

**Version 2.0 | 17 October 2026 | Proposed refinement**

This is the complete textual counterpart to the thirteen-page landscape guide. The identity is MEAT. This edition aligns a recovered identity proposal with the rebuilt app direction and supplies usable production assets. It does not establish brand approval, trademark clearance, original vector recovery, independent age verification, or a live online service.

## 01. Cover: connection on your terms

The cover uses the supplied reversed production master: the MEAT name in uppercase with a coral slanted accent on Charcoal. "Connection. On your terms." is proposed communication copy, not a recovered permanent tagline. The full brand name is MEAT. NEXT may describe the preview edition outside the logo; it is not part of the production master.

## 02. Introduction: clear intentions, more possibility

The current MEAT preview centres on adults, particularly men seeking men in Perth. Desire, dating, friendship and community belong in the same conversation. The intended impression is confident, direct and warm, with room for users to describe themselves without forced labels.

### Evidence and decision status

| Element | Status in this edition |
|---|---|
| Exact name MEAT | Established by the user's request and recovered guide; retained uppercase. |
| Earlier MEAT app brand guide, version 1.0 | Recovered reference, preserved in `references/MEAT-app-brand-guide-prior.pdf`; its approval history is unknown. |
| Montserrat Black and Inter direction | Recovered from pages 3 and 9 of the earlier proposed guide; retained. |
| Earlier palette | Preserved in the reference: Ink #10090C, Merlot #26151C, Coral #FF5B67, Cream #FFF0EC and Rose #D9A7B4. |
| Current Charcoal, Coral, Lime, Paper, Panel and Muted tokens | Proposed v2 refinement matching the rebuilt app direction. |
| Slanted bar and current full signature | Proposed refinement of the app's existing visual accent. |
| Production SVG paths | Newly reconstructed artwork, not an extracted original master. |
| Plain compact M | Reconstructed from the prior compact direction; original vector not recovered. |
| Optional M / slash | Proposed additional companion; not the primary favicon. |
| Clear space and minimum sizes | Proposed rules for this supplied geometry, reviewed at reference size. |

The earlier guide described MEAT's context within a wider brand architecture. That reference is retained without using it to infer legal ownership or to impose other brands' fonts, colours or endorsements.

### The profile language

The upgraded app provides **15 optional profile groups, 32 interest choices and four interest stances**. These are the requested profile features implemented in the local preview, not evidence of a live member network.

1. Why I'm here
2. What I'm looking for
3. Who I'd like to meet
4. My sexual role
5. Roles I'm interested in
6. My kink dynamic
7. What I'm into
8. My experience
9. How to approach me
10. My boundaries
11. Relationship situation
12. Relationship style
13. How I like to meet
14. Hosting and travel
15. Right now

Every field is optional. An unspecified answer must stay unspecified. People may choose sex, romance, friendship or more than one motivation. The brand should not shame a person's choices or suggest that a preference is consent to an interaction.

## 03. The wordmark

Use **MEAT** in uppercase. Use **MEAT app** when the descriptor helps; `app` stays lowercase. Do not expand the name into an acronym. Use the provided SVG outlines for production rather than retyping the name, guessing the spacing or rebuilding the slanted accent.

Montserrat Black is documented in the recovered 1.0 guide. The new kit's outlined lettering is a reconstruction using sourced font software. It is not a claim that the original working font binary, kerning file or editable vector master was recovered.

The coral slanted bar follows the rebuilt app's visual direction and is a proposed addition to the earlier wordmark. It belongs to the complete signature: keep its geometry, spacing, proportion and colour from the supplied file. Do not detach it and invent a new lockup.

NEXT is an optional preview edition label only. If used, set it as separate descriptive text outside the logo's clear space. Do not add it to the production wordmark or rename the brand MEAT NEXT.

## 04. Logo versions

| Master | Appearance | Intended use |
|---|---|---|
| `logos/svg/meat-primary.svg` | Charcoal lettering with coral bar | Light surfaces |
| `logos/svg/meat-reversed.svg` | Paper lettering with coral bar | Dark surfaces |
| `logos/svg/meat-black.svg` | Solid black | Single-colour reproduction on light |
| `logos/svg/meat-white.svg` | Solid white | Single-colour reproduction on dark |
| `logos/svg/meat-wordmark-coral.svg` | Plain MEAT in Coral | Secondary continuity companion |
| `logos/svg/meat-mark-coral.svg` | Coral plain M | Dark compact placements |
| `logos/svg/meat-mark-charcoal.svg` | Charcoal compact companion | Light compact placements |
| `logos/svg/meat-mark-white.svg` | White plain M | Dark single-colour placements |
| `logos/svg/meat-mark-slash-reversed.svg` | Paper M with Coral slash | Optional compact secondary signature |

The earlier proposal used a coral wordmark. The two-colour v2 signatures are a declared refinement, not a retroactive claim that the prior proposal was approved or superseded by an earlier instruction. All supplied versions use consistent underlying geometry.

## 05. Clear space and minimum size

For the complete signature, let **x equal half the height of the capital M**. Keep an equal margin of x around every visible edge of the artwork, including the slanted bar. Measure from actual artwork bounds rather than the transparent canvas. Keep copy, crop edges, photographs and unrelated marks outside the clear space.

Proposed minimum screen sizes for these reconstructed assets:

| Variant | Minimum visible width | Condition |
|---|---|---|
| Full slash signature | 112 px | Use a larger version where the name needs more prominence. |
| Plain wordmark | 88 px | Continuity companion without the slash. |
| Plain compact M | 24 px | General compact use; add a MEAT label in unfamiliar contexts. |
| Optional M / slash | 32 px | Secondary compact signature, never the favicon. |
| Favicon | 16 px canvas | Specific inspected favicon exception; not a general logo minimum. |

The earlier guide proposed 88 px for its wordmark and 16 px for its simpler M. The full v2 signature minimum increases to 112 px for the additional slanted bar; the plain wordmark retains the 88 px reference minimum. The 24 px plain-M rule is a general-use proposal, separate from its 16 px favicon use. Native-size specimens in this guide use one PDF point as one reference pixel in a 72 dpi render. Final interface scaling, density and rendering still need inspection. No production print minimum is established in this edition; proof physical output with the supplier.

## 06. Misuse

Do not stretch or squash the signature. Do not rotate the whole master: retain the lean already drawn into the accent. Do not improvise colours, use a low-contrast version on the wrong ground, crowd the clear space, attach NEXT to the artwork, add an outline or shadow, redraw the wordmark, or introduce an unverified registration mark.

The PDF demonstrates incorrect stretching, rotation, colour, contrast, crowding and attached edition text using the actual supplied vectors. Those altered guide examples are instructional only and are not production assets.

## 07. Palette

The v2 palette is a proposed app-aligned refinement. Exact digital sRGB values are authoritative for this kit.

| Colour | Hex | RGB | Role |
|---|---|---|---|
| Charcoal | `#0E1014` | 14 / 16 / 20 | The primary ground. Calm, deep and direct. |
| Coral Pink | `#FF6389` | 255 / 99 / 137 | The signature accent. Use for identity and the next action. |
| Soft Lime | `#B7DFA5` | 183 / 223 / 165 | A secondary accent. Pair with words, never a promise. |
| Paper | `#F5F3F0` | 245 / 243 / 240 | Primary text on dark; open space on light. |
| Panel | `#17191F` | 23 / 25 / 31 | A quiet surface for cards and grouped controls. |
| Slate | `#9C9DA9` | 156 / 157 / 169 | Secondary copy on dark. Keep essential text strong. |

Keep Charcoal as the main ground and use Coral purposefully for identity and clear actions. Lime is a supporting accent; it must not imply that a person is verified, safe, available or consenting. Use words or symbols alongside colour so a choice, warning or state is not communicated by hue alone.

Paper and Panel create a calm hierarchy. Muted supports secondary text on dark backgrounds; important actions and essential content should remain prominent. No Pantone equivalence, press profile or CMYK guarantee is defined. The previous palette is retained inside the reference PDF for traceability.

## 08. Colour pairings

Calculated solid-token contrast ratios:

| Pair | Ratio | AA normal text | Intended use |
|---|---|---|---|
| Paper on Charcoal | 17.19:1 | Pass | Primary text |
| Coral Pink on Charcoal | 6.71:1 | Pass | Identity and links |
| Charcoal on Coral Pink | 6.71:1 | Pass | Primary action |
| Charcoal on Soft Lime | 12.80:1 | Pass | Secondary highlight |
| Coral Pink on Paper | 2.56:1 | Fail | Avoid for normal text |
| Paper on Coral Pink | 2.56:1 | Fail | Avoid for normal text |

WCAG 2.2 AA requires at least 4.5:1 for normal text and 3:1 for qualifying large text. Threshold decisions use unrounded ratios. The table covers only these solid foreground/background pairs; it does not certify the brand, guide or interface as accessible. Opacity, gradients, photographs, focus treatments, font size, weight and actual UI states need their own checks. Avoid Paper on Coral and Coral on Paper for normal copy. A logo exception in the standard is not a reason to choose an unreadable placement.

Reference: [W3C Understanding SC 1.4.3: Contrast (Minimum)](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), consulted 17 October 2026. Full computed token records are supplied in `tokens/`.

## 09. Typography

Retain the earlier guide's pairing: **Montserrat Black** for short display statements and the wordmark; **Inter** for readable functional content. Use the real bundled font files and weights. Do not simulate bold, allow silent fallback in production artwork or assume that the original font binary was recovered.

| Role | Family and weight | Suggested size / line height | Example |
|---|---|---|---|
| Display | Montserrat Black, 900 | 56 / 60 px, adapted to placement | MAKE IT YOUR CALL. |
| Page heading | Inter Bold, 700 | 32 / 38 px | Your next connection. |
| Body | Inter Regular, 400 | 17 / 26 px | Say what you want. Share what feels right. |
| Control | Inter Bold, 700 | 15 / 20 px | Save preferences |
| Caption | Inter Medium, 500 | 12 / 18 px | Saved on this device. |

These are starting scales, not a requirement to shrink important text. Keep labels short, preserve natural reading order, and let content wrap instead of forcing text into narrow containers. The PDF uses larger presentation sizes where helpful. Font licences, provenance and supplied files live in `fonts/`; retain the licences when redistributing the font software. Production SVG lettering is outlined and does not need a font installation merely to display.

## 10. Icons

The plain compact M retains the direction from the earlier guide, with newly reconstructed production outlines. The M / slash is an optional additional companion with a 32 px minimum, not the primary app or favicon icon. Use the supplied transparent glyphs, opaque app tiles and favicon assets rather than independently recreating them. Keep the built-in padding in app tiles and avatars. In a new context, accompany the compact mark with the MEAT name until recognition is clear.

The proposed general compact minimum is 24 px visible width. The delivered 16 px favicon is a narrowly defined exception. Check native-size reductions, not enlarged previews alone. Do not use the full wordmark inside a small icon tile.

For maskable output, the background fills the square canvas and important foreground stays within the centred circle whose radius is 40% of the side. The kit supplies a separate transparent foreground so that this can be measured independently of the opaque tile. The circle drawn on the guide's specimen is instructional and is not in the finished export.

Reference: [W3C Web Application Manifest: icon masks](https://www.w3.org/TR/appmanifest/#icon-masks). Platform crop behaviour should be checked when the icon is installed in a particular product.

## 11. Applications

The PDF places the actual finished social files from this kit. It does not redraw their logos or substitute mock screenshots.

| File | Canvas | Purpose |
|---|---|---|
| `social/meat-open-graph-1200x630.png` | 1200 × 630 px | General link-preview artwork |
| `social/meat-banner-1500x500.png` | 1500 × 500 px | Reusable horizontal banner |
| `social/meat-square-1080x1080.png` | 1080 × 1080 px | Reusable square artwork |

These are practical reusable formats, not guarantees for every platform. Keep the important identity inside the destination's visible crop. Adapt campaign copy to the actual feature or event. Do not imply the artwork advertises a live member service when only the local preview is available. Do not place real people's portraits, endorsements or activity indicators without appropriate source and permission.

## 12. Voice and tone

**A clear yes. A kind no. Room to decide.**

MEAT's voice is direct about desire and clear about choice. Adult labels can be plain and non-graphic. Use the words that help people understand their own selections; avoid coy euphemism, pressure, fetishising labels or exaggerated confidence claims.

| Principle | Use | Avoid |
|---|---|---|
| Say it plainly | Casual sex; Go on dates; Friends with benefits | Vague claims that hide the actual choice |
| Leave room | Choose what feels like you. You can leave this blank. | Choose one or you cannot continue. |
| Name the boundary | Ask before explicit photos. | A preference treated as permission |
| Be specific about privacy | Saved on this device. | Private vault, anonymous or encrypted without evidence |
| Tell the product truth | Sample message - not sent. | Live chat or message delivered when no service exists |
| Describe the gate honestly | Adult self-declaration | Age verified without independent verification |

Interest stances are **Into it**, **Curious**, **Discuss first** and **Not for me**. None authorises a specific interaction. All fifteen profile groups remain optional. A person's role, relationship style, gender or curiosity should not be turned into a stereotype.

### The 32-interest vocabulary

Use the exact current catalogue labels where a product selection is intended. These are neutral profile vocabulary, not instructions or promises.

### Touch & intimacy

Kissing, Cuddling, Sensual massage, Mutual touch, Taking it slow.

### Sex & play

Oral sex, Anal sex, Vaginal / front-hole sex, Mutual masturbation, Non-penetrative sex, Sex toys, Strap-on play, Dirty talk.

### Kink & style

BDSM, Bondage, Adult roleplay, Sensation play, Spanking, Power exchange, Praise, Leather, Latex, Harnesses, Lingerie, Foot play.

### Shared experiences

Threesomes, Group play, Watching, by agreement, Being watched, by agreement.

### Digital intimacy

Sexting, Private photo sharing, Consensual video intimacy.

### Current preview boundaries

The current implementation stores choices in the browser and uses fictional example profiles. Sharing controls demonstrate what a viewer could see; they do not publish a profile. Local sample conversation controls do not deliver messages to other people. Do not advertise live matching, member verification, emergency alerts, moderation response, secure encryption or real availability without separately implemented and verified services.

## 13. Asset kit and handoff

| Location | Contents |
|---|---|
| `logos/svg/` | Self-contained outlined production signatures and compact companions |
| `logos/png/` | Transparent raster logo exports at 512, 1024 and 2048 px canvas widths |
| `icons/` | Favicon, Apple touch icon, install icons, maskable tile and measurable foreground |
| `social/` | Finished link-preview, banner and square artwork |
| `fonts/` | Sourced font software, licences and provenance |
| `tokens/` | sRGB CSS/JSON and calculated solid-pair contrast |
| `source/` | Portable production scripts |
| `references/` | Preserved earlier MEAT app brand guide |
| `asset-manifest.json` | Machine-readable declared inventory |
| `MEAT_Brand_Guide.pdf` | Reviewed thirteen-page landscape guide |
| `MEAT_Brand_Guide.md` | This full textual counterpart |
| `README.md` | Usage, dependencies and rebuild instructions |

Use SVG for scalable production artwork and PNG for fixed-size placement. Match the chosen logo version to its ground. Preserve the complete kit's relative folder structure when rebuilding. Read `README.md` before regeneration. Keep every supplied font with its licence. Asset presence, format validation and visual review do not establish legal ownership, originality, trademark clearance or official brand approval.

### Sources used

1. `references/MEAT-app-brand-guide-prior.pdf`, version 1.0, October 2026: prior proposed typography, palette, naming and thirteen-page structure.
2. The supplied `MEAT_Profile_Selections_Upgrade.md`, version 1.0, 17 October 2026, and the rebuilt app's catalogue: fifteen optional groups, thirty-two interests, four stances and the current local-preview scope.
3. The current MEAT app reconstruction: Charcoal, Coral and Lime direction, uppercase name and slanted accent. This guide is not a source audit of the original hosted app.
4. W3C WCAG 2.2 contrast guidance and Web Application Manifest icon-mask guidance, linked above.
5. Bundled font provenance and licences in `fonts/` for the exact supplied software.
