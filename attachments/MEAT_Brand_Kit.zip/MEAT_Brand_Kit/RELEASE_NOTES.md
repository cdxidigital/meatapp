# MEAT app and brand release

**Edition:** 2.0 · 17 October 2026

## App handoff

The rebuilt MEAT app is available at [meat-next.jamison-park-3726.chatgpt.site](https://meat-next.jamison-park-3726.chatgpt.site) as a private owner preview. Its final branded deployment succeeded at **2026-10-17 14:59:06 UTC** (22:59:06 in Perth), from source commit `b0cb16f105dad1d284e3b759c6443ecbe1386863`.

The companion `MEAT_App_Source.zip` contains the complete final source, local assets, tests, original upgrade specification, reconstruction evidence and implementation documentation. The source archive is delivered separately from this brand kit.

The app implements 15 optional profile groups, 32 interests and four interest stances; field audiences and independent discovery opt-in; expiring availability; combined discovery filters; saved, hidden and blocked profiles; browser-local conversations; import/export; photo uploads; recovery and reset. Eight adult sample profiles are fictional.

Verification passed 23 profile-domain cases, 15 storage cases and 12 app integration scenarios, plus the final static checks of six browser JavaScript files and 26 local references. These are 50 substantive cases/scenarios. The app source includes the detailed validation record and commands to reproduce the checks.

Accounts, remote message delivery, backend-enforced sharing, remote moderation and background reminders are not connected. Adult entry uses self-declaration. Browser and device rendering were not tested in this environment.

## Identity handoff

The exact brand remains **MEAT**. This edition retains the earlier proposed Montserrat Black / Inter direction and supplies a proposed refinement of the wordmark geometry, coral slanted accent and upgraded app palette. The final app already uses the kit's matching dark-surface signature, icons, fonts and colour tokens.

The kit contains the 13-page visual guide and its Markdown counterpart; 11 outlined logo masters with 33 transparent PNG exports; compact marks, browser and app icons; three social layouts in SVG and PNG; four original font files with their licences and provenance; colour and typography tokens; and portable source builders.

`references/MEAT-app-brand-guide-prior.pdf` preserves the earlier guide. `references/MEAT_Profile_Selections_Upgrade.md` preserves the requested profile-upgrade brief. The original vector masters and prior approval history were not established; this edition identifies its new design decisions as proposals.

## Verification records

- `audit-report.json`: final machine audit of the declared kit inventory and asset properties.
- `tokens/guide-visual-review.json`: every-page review of the delivered PDF and its exact hash.
- `tokens/asset-visual-review.json`: inspected production logos, icons and social assets.
- `tokens/portable-rebuild-check.json`: isolated offline rebuild comparison using the bundled fonts.
- `asset-manifest.json`: relative paths and expected properties for production files.

The supplied builders resolve paths relative to the kit. After installing the documented dependencies, they can rebuild offline. Rebuilding a PDF changes the delivered review scope: render and inspect the regenerated pages before redistributing that new guide.
