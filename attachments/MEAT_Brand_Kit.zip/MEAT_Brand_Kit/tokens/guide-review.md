# MEAT guide: final visual review ledger

**Status: final, reviewed and frozen.** All thirteen pages were inspected individually at 1600 × 900 pixels (90 dpi), including a complete recheck after the text-state and clear-space corrections. A contact sheet was not used as a substitute for page review.

Final PDF SHA-256: `3b12d6d3b6b1b748fa0b59f1e8755c1abddd3c829565a7b80f751c7b4914502f`.

## Corrections and rechecks

1. **Shared PDF character-spacing state caused paragraph overflow on page 2.** Isolated text state for every text/paragraph operation, rebuilt and re-rendered all pages, then individually reviewed all thirteen.

2. **Cover and logo-specimen placements encroached on the proposed clear-space margin.** Repositioned/resized specimen placement and moved or removed adjacent guide content on pages 1, 3 and 4; individually rechecked.

3. **Social assets were adjusted by the asset owner after an earlier guide build.** Rebuilt page 11 from the frozen final social PNGs; inspected all three applications.

4. **README dependency named CairoSVG although the asset builder imports fitz.** Corrected both generator and produced README to PyMuPDF and removed the unused native-Cairo note.

5. **Page 12 review PNG was truncated while the PDF remained valid.** Regenerated page 12 alone, verified complete PNG decoding, visually inspected it and replaced the truncated canonical review image.

## Individual page decisions

| Page | Section | Result | Inspection notes |
|---|---|---|---|
| 01 | Cover | Pass | Exact reversed master, intact MEAT lettering, sufficient clear space, clear title and footer; cover repositioned and nearby label/rule removed, then rechecked. |
| 02 | Introduction | Pass | All fifteen group labels readable. Evidence-status paragraph wraps inside its card; shared character-spacing defect corrected and rechecked. |
| 03 | The wordmark | Pass | Actual primary outline, clear space around complete signature, distinct lettering/slash/naming columns; master resized and nearby internal label removed, then rechecked. |
| 04 | Logo versions | Pass | Four matching production variants plus plain coral companion; caption spacing and lower companion adjusted to respect clear space, then rechecked. |
| 05 | Clear space and size | Pass | Equal half-capital-height boundary, intact minimum-size specimens, and explicit general-M versus favicon distinction; no overlap. |
| 06 | Misuse | Pass | Six intentionally incorrect treatments are visibly labelled and separated; real SVG outlines underpin every example. |
| 07 | Palette | Pass | All six exact hex and RGB values are readable; core and supporting roles remain clear and unobstructed. |
| 08 | Colour pairings | Pass | Six calculated pairings, correct pass/fail labels, legible scope statement and W3C source; no clipped text. |
| 09 | Typography | Pass | Actual Montserrat Black and three actual Inter weights render distinctly; specimen hierarchy, provenance note and body text remain legible. |
| 10 | Icons | Pass | Actual app tile, compact glyph, maskable foreground circle and native icon files are visible; general 24px and favicon 16px rules are distinct. |
| 11 | Applications | Pass | Final corrected Open Graph, banner and square PNGs are fully placed with correct aspect ratios; all labels and footer readable. Rebuilt after asset freeze. |
| 12 | Voice and tone | Pass | Direct non-graphic adult voice, four stances and local-preview statements remain legible. Truncated review PNG was regenerated and decoded, then individually inspected. |
| 13 | The asset kit | Pass | Folder inventory, production file guidance, font/licence grouping and handoff copy are clear; source and approval status remain explicit. |

## Structural evidence

- PDF: 13 pages, each 1280 × 720 points.
- All 307 recorded authoring boxes fall within the page bounds.
- All thirteen final review images decode fully and measure 1600 × 900 pixels.
- All pages contain selectable text. Actual text-span fonts: Inter-Bold, Inter-Medium, Inter-Regular, Montserrat-Black.
- The Markdown counterpart includes all fifteen group names and all thirty-two interest labels.
- Actual production SVGs, final social PNGs and four bundled font files were used; their hashes are recorded in `guide-visual-review.json`.
- No unresolved visual findings remain. Root also independently reviewed the final key-page images.

## Frozen authored files

| File | Bytes | SHA-256 |
|---|---:|---|
| `MEAT_Brand_Guide.pdf` | 243,692 | `3b12d6d3b6b1b748fa0b59f1e8755c1abddd3c829565a7b80f751c7b4914502f` |
| `MEAT_Brand_Guide.md` | 18,073 | `68b58ebc91816df0c3605ffa8b61efe61e13f3aa10231b4336fb531dbcaffa44` |
| `README.md` | 4,161 | `dcf4d9290b4d6777af301e25b2ee08bfc0eb0ee1e6ba787bec5c506511901cef` |
| `source/build_guide.py` | 54,171 | `d9e2c6a4ed71819834710989d80c17804af25f1fdb2c6bef40cb4bd8dbe89e09` |

This ledger covers the PDF/document artifact. It does not claim browser QA, original-master recovery, legal brand approval, trademark clearance, or a full interface accessibility assessment. Asset-specific review is recorded separately by the asset owner.
